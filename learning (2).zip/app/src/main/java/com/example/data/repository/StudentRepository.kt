package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StudentRepository(private val context: Context) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirestoreHelper.getFirestore(context)

    companion object {
        private const val TAG = "StudentRepository"
    }

    private fun requireStudentId(): String {
        return auth.currentUser?.uid ?: error("غير مصرح: يجب تسجيل الدخول للوصول إلى الحساب")
    }

    // ----------------------------------------------------
    // ONLINE LESSONS
    // ----------------------------------------------------
    suspend fun getScheduledLessons(): List<Lesson> {
        requireStudentId()
        return try {
            firestore.collection("lessons")
                .orderBy("dateTimeMillis", Query.Direction.ASCENDING)
                .get().await()
                .toObjects(Lesson::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // ATTENDANCE
    // ----------------------------------------------------
    suspend fun getMyAttendance(): List<AttendanceRecord> {
        val uid = requireStudentId()
        return try {
            firestore.collection("attendanceRecords")
                .whereEqualTo("studentUid", uid)
                .get().await()
                .toObjects(AttendanceRecord::class.java)
                .sortedByDescending { it.recordedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // EXAMINATIONS & SUBMISSIONS
    // ----------------------------------------------------
    suspend fun getPublishedExaminations(): List<Exam> {
        requireStudentId()
        return try {
            firestore.collection("examinations")
                .whereEqualTo("isPublished", true)
                .get().await()
                .toObjects(Exam::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getExamQuestions(examId: String): List<ExamQuestion> {
        requireStudentId()
        return try {
            // Returns ONLY questions without any answer keys or correct answers!
            firestore.collection("examinationQuestions")
                .whereEqualTo("examId", examId)
                .get().await()
                .toObjects(ExamQuestion::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getMySubmissions(): List<ExamSubmission> {
        val uid = requireStudentId()
        return try {
            firestore.collection("examinationSubmissions")
                .whereEqualTo("studentUid", uid)
                .get().await()
                .toObjects(ExamSubmission::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun submitExam(
        examId: String,
        examTitle: String,
        answers: Map<String, String>
    ): Result<String> {
        val uid = requireStudentId()
        return try {
            // Check if already submitted
            val existing = firestore.collection("examinationSubmissions")
                .whereEqualTo("examId", examId)
                .whereEqualTo("studentUid", uid)
                .get().await()

            if (!existing.isEmpty) {
                return Result.failure(Exception("لقد قمت بتسليم هذا الامتحان مسبقاً!"))
            }

            // Get user info
            val userDoc = firestore.collection("users").document(uid).get().await()
            val user = userDoc.toObject(User::class.java)

            val submissionId = UUID.randomUUID().toString()
            val submission = ExamSubmission(
                id = submissionId,
                examId = examId,
                examTitle = examTitle,
                studentUid = uid,
                studentCode = user?.studentCode ?: "",
                studentName = user?.fullName ?: "",
                answers = answers,
                submittedAt = System.currentTimeMillis(),
                status = ExamSubmission.STATUS_SUBMITTED
            )

            // Save submission to Firestore
            firestore.collection("examinationSubmissions").document(submissionId).set(submission).await()

            // Neutral confirmation message per requirements:
            // "تم تسليم الامتحان بنجاح، وسيتم مراجعة النتيجة بواسطة الإدارة."
            Result.success("تم تسليم الامتحان بنجاح، وسيتم مراجعة النتيجة بواسطة الإدارة.")
        } catch (e: Exception) {
            Log.e(TAG, "Exam submission failed: ${e.message}", e)
            Result.failure(Exception("فشل إرسال الإجابات: ${e.message}"))
        }
    }

    // ----------------------------------------------------
    // CURRICULUM
    // ----------------------------------------------------
    suspend fun getCurriculumMaterials(): List<CurriculumItem> {
        requireStudentId()
        return try {
            firestore.collection("curricula")
                .whereEqualTo("isPublished", true)
                .get().await()
                .toObjects(CurriculumItem::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // FINANCIAL SUMMARY
    // ----------------------------------------------------
    suspend fun getMyFinancialSummary(): StudentFinancialSummary {
        val uid = requireStudentId()
        return try {
            val userDoc = firestore.collection("users").document(uid).get().await()
            val user = userDoc.toObject(User::class.java)

            val feesSnap = firestore.collection("studentFees")
                .whereEqualTo("studentUid", uid)
                .get().await()
            val totalFees = feesSnap.documents.sumOf { it.getDouble("amount") ?: 0.0 }

            val paymentsSnap = firestore.collection("paymentRecords")
                .whereEqualTo("studentUid", uid)
                .get().await()
            val totalPaid = paymentsSnap.documents.sumOf { it.getDouble("amount") ?: 0.0 }

            val remaining = (totalFees - totalPaid).coerceAtLeast(0.0)
            val status = when {
                totalFees == 0.0 -> "لا توجد رسوم"
                totalPaid >= totalFees -> "مسدد بالكامل"
                totalPaid > 0.0 -> "مسدد جزئياً"
                else -> "غير مسدد"
            }

            StudentFinancialSummary(
                studentUid = uid,
                studentCode = user?.studentCode ?: "",
                studentName = user?.fullName ?: "",
                totalFees = totalFees,
                totalPaid = totalPaid,
                remainingBalance = remaining,
                paymentStatus = status
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching student financial summary: ${e.message}")
            StudentFinancialSummary()
        }
    }

    suspend fun getMyFees(): List<StudentFee> {
        val uid = requireStudentId()
        return try {
            firestore.collection("studentFees")
                .whereEqualTo("studentUid", uid)
                .get().await()
                .toObjects(StudentFee::class.java)
                .sortedByDescending { it.dueDateMillis }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getMyPayments(): List<PaymentRecord> {
        val uid = requireStudentId()
        return try {
            firestore.collection("paymentRecords")
                .whereEqualTo("studentUid", uid)
                .get().await()
                .toObjects(PaymentRecord::class.java)
                .sortedByDescending { it.paymentDateMillis }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // NOTIFICATIONS
    // ----------------------------------------------------
    suspend fun getMyNotifications(): List<AppNotification> {
        val uid = requireStudentId()
        return try {
            val general = firestore.collection("notifications")
                .whereEqualTo("targetUid", "all")
                .get().await()
                .toObjects(AppNotification::class.java)

            val specific = firestore.collection("notifications")
                .whereEqualTo("targetUid", uid)
                .get().await()
                .toObjects(AppNotification::class.java)

            (general + specific).sortedByDescending { it.createdAt }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
