package com.example.data.model

data class StudentCode(
    val code: String = "",
    val studentName: String = "",
    val studentEmail: String = "",
    val studentUid: String = "",
    val status: String = STATUS_AVAILABLE, // "available", "active", "revoked"
    val assignedClass: String = "الصف الأول الثانوي",
    val createdAt: Long = System.currentTimeMillis(),
    val activatedAt: Long = 0L,
    val revokedAt: Long = 0L,
    val createdBy: String = ""
) {
    companion object {
        const val STATUS_AVAILABLE = "available"
        const val STATUS_ACTIVE = "active"
        const val STATUS_REVOKED = "revoked"
    }

    val isAvailable: Boolean get() = status == STATUS_AVAILABLE
    val isActive: Boolean get() = status == STATUS_ACTIVE
    val isRevoked: Boolean get() = status == STATUS_REVOKED
}
