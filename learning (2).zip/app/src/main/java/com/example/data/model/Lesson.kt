package com.example.data.model

data class Lesson(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val subjectName: String = "",
    val className: String = "جميع الفصول",
    val dateTimeMillis: Long = System.currentTimeMillis(),
    val durationMinutes: Int = 60,
    val meetingLink: String = "",
    val status: String = STATUS_SCHEDULED, // "scheduled", "in_progress", "completed", "cancelled"
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = ""
) {
    companion object {
        const val STATUS_SCHEDULED = "مجدولة"
        const val STATUS_IN_PROGRESS = "جارية الآن"
        const val STATUS_COMPLETED = "مكتملة"
        const val STATUS_CANCELLED = "ملغاة"
    }
}

data class AttendanceRecord(
    val id: String = "",
    val lessonId: String = "",
    val lessonTitle: String = "",
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val status: String = STATUS_UNRECORDED, // "حضر", "غائب", "تأخر", "لم يتم تسجيل الحضور"
    val recordedAt: Long = System.currentTimeMillis(),
    val recordedBy: String = "",
    val notes: String = ""
) {
    companion object {
        const val STATUS_PRESENT = "حضر"
        const val STATUS_ABSENT = "غائب"
        const val STATUS_LATE = "تأخر"
        const val STATUS_UNRECORDED = "لم يتم تسجيل الحضور"
    }
}
