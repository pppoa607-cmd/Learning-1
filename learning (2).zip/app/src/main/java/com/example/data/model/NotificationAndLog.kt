package com.example.data.model

data class AppNotification(
    val id: String = "",
    val targetUid: String = "all", // "all" or specific studentUid
    val title: String = "",
    val body: String = "",
    val type: String = "announcement", // "lesson", "exam", "fee", "announcement"
    val createdAt: Long = System.currentTimeMillis()
)

data class ActivityLogItem(
    val id: String = "",
    val adminUid: String = "",
    val adminName: String = "",
    val actionType: String = "",
    val description: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class AppSettings(
    val id: String = "main",
    val enableStudentFinancialView: Boolean = true,
    val enableStudentAttendanceView: Boolean = true,
    val announcementBanner: String = "مرحباً بكم في منصة Learning للعام الدراسي الجديد"
)
