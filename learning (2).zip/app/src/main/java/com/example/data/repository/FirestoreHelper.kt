package com.example.data.repository

import android.content.Context
import com.example.R
import com.google.firebase.firestore.FirebaseFirestore

object FirestoreHelper {
    private var instance: FirebaseFirestore? = null

    fun getFirestore(context: Context): FirebaseFirestore {
        return instance ?: synchronized(this) {
            instance ?: run {
                val dbId = context.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                instance = db
                db
            }
        }
    }
}
