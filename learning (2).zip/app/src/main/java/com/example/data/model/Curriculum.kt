package com.example.data.model

data class CurriculumItem(
    val id: String = "",
    val subjectName: String = "",
    val className: String = "جميع الفصول",
    val title: String = "",
    val description: String = "",
    val unitName: String = "",
    val chapterName: String = "",
    val fileUrl: String = "",
    val fileType: String = TYPE_PDF, // "pdf", "doc", "video", "link"
    val isPublished: Boolean = true,
    val availableFromMillis: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val TYPE_PDF = "pdf"
        const val TYPE_DOC = "doc"
        const val TYPE_VIDEO = "video"
        const val TYPE_LINK = "link"
    }
}
