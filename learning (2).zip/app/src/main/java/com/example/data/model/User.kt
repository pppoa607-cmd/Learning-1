package com.example.data.model

data class User(
    val uid: String = "",
    val email: String = "",
    val fullName: String = "",
    val role: String = ROLE_STUDENT, // "admin" or "student"
    val accountStatus: String = STATUS_PENDING, // "pending", "active", "suspended"
    val studentCode: String = "",
    val className: String = "الصف الأول الثانوي",
    val phone: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val ROLE_ADMIN = "admin"
        const val ROLE_STUDENT = "student"

        const val STATUS_ACTIVE = "active"
        const val STATUS_PENDING = "pending"
        const val STATUS_SUSPENDED = "suspended"
    }

    val isAdmin: Boolean get() = role == ROLE_ADMIN
    val isStudent: Boolean get() = role == ROLE_STUDENT
    val isActive: Boolean get() = accountStatus == STATUS_ACTIVE
}
