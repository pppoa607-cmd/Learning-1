package com.example.data.model

data class Exam(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val subjectName: String = "",
    val className: String = "جميع الفصول",
    val totalGrade: Double = 100.0,
    val passingGrade: Double = 50.0,
    val timeLimitMinutes: Int = 45,
    val startDateMillis: Long = System.currentTimeMillis(),
    val deadlineMillis: Long = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L),
    val allowedAttempts: Int = 1,
    val instructions: String = "يرجى قراءة الأسئلة بعناية قبل الإجابة. لا يمكن تعديل الإجابات بعد التسليم.",
    val isPublished: Boolean = false,
    val questionsCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = ""
)

data class ExamQuestion(
    val id: String = "",
    val examId: String = "",
    val questionText: String = "",
    val questionType: String = TYPE_MULTIPLE_CHOICE, // "multiple_choice", "true_false", "short_answer"
    val options: List<String> = emptyList(),
    val points: Double = 10.0
) {
    companion object {
        const val TYPE_MULTIPLE_CHOICE = "multiple_choice"
        const val TYPE_TRUE_FALSE = "true_false"
        const val TYPE_SHORT_ANSWER = "short_answer"
    }
}

// Stored securely, accessible ONLY by admin
data class ExamAnswerKey(
    val questionId: String = "",
    val examId: String = "",
    val correctAnswer: String = ""
)

data class ExamSubmission(
    val id: String = "",
    val examId: String = "",
    val examTitle: String = "",
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val answers: Map<String, String> = emptyMap(), // questionId -> studentAnswer
    val submittedAt: Long = System.currentTimeMillis(),
    val status: String = STATUS_SUBMITTED // "submitted", "graded"
) {
    companion object {
        const val STATUS_SUBMITTED = "تم التسليم"
        const val STATUS_GRADED = "تم التصحيح"
    }
}

// Stored securely in examinationGrades collection, NEVER readable by student directly
data class ExamGrade(
    val id: String = "",
    val submissionId: String = "",
    val examId: String = "",
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val score: Double = 0.0,
    val totalScore: Double = 100.0,
    val isPassed: Boolean = false,
    val feedback: String = "",
    val gradedBy: String = "",
    val gradedAt: Long = System.currentTimeMillis()
)
