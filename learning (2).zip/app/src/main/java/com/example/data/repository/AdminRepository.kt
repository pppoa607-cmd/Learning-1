package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*

class AdminRepository(private val context: Context) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirestoreHelper.getFirestore(context)

    companion object {
        private const val TAG = "AdminRepository"
    }

    private fun requireAdminId(): String {
        return auth.currentUser?.uid ?: error("غير مصرح: يجب تسجيل الدخول كمسؤول")
    }

    // ----------------------------------------------------
    // ACTIVITY LOGGING
    // ----------------------------------------------------
    suspend fun logActivity(actionType: String, description: String) {
        try {
            val adminUid = auth.currentUser?.uid ?: "system"
            val adminName = auth.currentUser?.displayName ?: "المسؤول"
            val logItem = ActivityLogItem(
                id = UUID.randomUUID().toString(),
                adminUid = adminUid,
                adminName = adminName,
                actionType = actionType,
                description = description,
                timestamp = System.currentTimeMillis()
            )
            firestore.collection("activityLogs").document(logItem.id).set(logItem).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write activity log: ${e.message}")
        }
    }

    suspend fun getActivityLogs(): List<ActivityLogItem> {
        return try {
            firestore.collection("activityLogs")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50)
                .get().await()
                .toObjects(ActivityLogItem::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // DASHBOARD OVERVIEW & STATISTICS
    // ----------------------------------------------------
    data class AdminStats(
        val totalStudents: Int = 0,
        val activeStudents: Int = 0,
        val suspendedStudents: Int = 0,
        val totalLessons: Int = 0,
        val upcomingLessons: Int = 0,
        val totalExaminations: Int = 0,
        val pendingSubmissions: Int = 0,
        val totalFees: Double = 0.0,
        val totalCollectedPayments: Double = 0.0,
        val outstandingBalances: Double = 0.0,
        val attendancePresentCount: Int = 0,
        val attendanceAbsentCount: Int = 0
    )

    suspend fun getDashboardStats(): AdminStats {
        requireAdminId()
        return try {
            val usersSnap = firestore.collection("users")
                .whereEqualTo("role", User.ROLE_STUDENT)
                .get().await()
            val totalStudents = usersSnap.size()
            val activeStudents = usersSnap.documents.count { it.getString("accountStatus") == User.STATUS_ACTIVE }
            val suspendedStudents = usersSnap.documents.count { it.getString("accountStatus") == User.STATUS_SUSPENDED }

            val now = System.currentTimeMillis()
            val lessonsSnap = firestore.collection("lessons").get().await()
            val totalLessons = lessonsSnap.size()
            val upcomingLessons = lessonsSnap.documents.count { (it.getLong("dateTimeMillis") ?: 0L) >= now }

            val examsSnap = firestore.collection("examinations").get().await()
            val totalExaminations = examsSnap.size()

            val submissionsSnap = firestore.collection("examinationSubmissions").get().await()
            val pendingSubmissions = submissionsSnap.documents.count { it.getString("status") == ExamSubmission.STATUS_SUBMITTED }

            val feesSnap = firestore.collection("studentFees").get().await()
            val totalFees = feesSnap.documents.sumOf { it.getDouble("amount") ?: 0.0 }

            val paymentsSnap = firestore.collection("paymentRecords").get().await()
            val totalPayments = paymentsSnap.documents.sumOf { it.getDouble("amount") ?: 0.0 }
            val outstanding = (totalFees - totalPayments).coerceAtLeast(0.0)

            val attendanceSnap = firestore.collection("attendanceRecords").get().await()
            val presentCount = attendanceSnap.documents.count { it.getString("status") == AttendanceRecord.STATUS_PRESENT }
            val absentCount = attendanceSnap.documents.count { it.getString("status") == AttendanceRecord.STATUS_ABSENT }

            AdminStats(
                totalStudents = totalStudents,
                activeStudents = activeStudents,
                suspendedStudents = suspendedStudents,
                totalLessons = totalLessons,
                upcomingLessons = upcomingLessons,
                totalExaminations = totalExaminations,
                pendingSubmissions = pendingSubmissions,
                totalFees = totalFees,
                totalCollectedPayments = totalPayments,
                outstandingBalances = outstanding,
                attendancePresentCount = presentCount,
                attendanceAbsentCount = absentCount
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching dashboard stats: ${e.message}")
            AdminStats()
        }
    }

    // ----------------------------------------------------
    // STUDENT ACCOUNTS
    // ----------------------------------------------------
    suspend fun getAllStudents(): List<User> {
        requireAdminId()
        return try {
            firestore.collection("users")
                .whereEqualTo("role", User.ROLE_STUDENT)
                .get().await()
                .toObjects(User::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun updateStudentStatus(uid: String, newStatus: String): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("users").document(uid).update(
                mapOf(
                    "accountStatus" to newStatus,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            logActivity("تحديث حالة الطالب", "تم تغيير حالة الحساب إلى $newStatus للمستخدم $uid")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // STUDENT ACCESS CODES ("إدارة أكواد الطلاب")
    // ----------------------------------------------------
    suspend fun getAllStudentCodes(): List<StudentCode> {
        requireAdminId()
        return try {
            firestore.collection("studentCodes")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(StudentCode::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun generateUniqueCodeString(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val sb = StringBuilder("LRN-$year-")
        for (i in 0 until 5) {
            sb.append(chars[random.nextInt(chars.length)])
        }
        return sb.toString()
    }

    suspend fun createStudentCode(
        studentName: String = "",
        assignedClass: String = "الصف الأول الثانوي",
        customCode: String? = null
    ): Result<StudentCode> {
        requireAdminId()
        return try {
            val codeStr = (customCode?.trim()?.uppercase()?.takeIf { it.isNotBlank() }
                ?: generateUniqueCodeString())

            // Prevent duplicate codes
            val check = firestore.collection("studentCodes").whereEqualTo("code", codeStr).get().await()
            if (!check.isEmpty) {
                return Result.failure(Exception("الكود $codeStr موجود بالفعل مسبقاً!"))
            }

            val docId = UUID.randomUUID().toString()
            val newCode = StudentCode(
                code = codeStr,
                studentName = studentName.trim(),
                assignedClass = assignedClass,
                status = StudentCode.STATUS_AVAILABLE,
                createdAt = System.currentTimeMillis(),
                createdBy = auth.currentUser?.email ?: "admin"
            )

            firestore.collection("studentCodes").document(docId).set(newCode).await()
            logActivity("توليد كود طالب", "تم إنشاء الكود $codeStr للطالب $studentName")
            Result.success(newCode)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun revokeStudentCode(code: String): Result<Unit> {
        requireAdminId()
        return try {
            val query = firestore.collection("studentCodes").whereEqualTo("code", code).get().await()
            for (doc in query.documents) {
                doc.reference.update(
                    mapOf(
                        "status" to StudentCode.STATUS_REVOKED,
                        "revokedAt" to System.currentTimeMillis()
                    )
                ).await()
            }
            logActivity("إلغاء كود طالب", "تم إيقاف صلاحية الكود $code")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // ONLINE LESSONS & ATTENDANCE
    // ----------------------------------------------------
    suspend fun getAllLessons(): List<Lesson> {
        return try {
            firestore.collection("lessons")
                .orderBy("dateTimeMillis", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(Lesson::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun createLesson(lesson: Lesson): Result<String> {
        requireAdminId()
        return try {
            val docId = UUID.randomUUID().toString()
            val newLesson = lesson.copy(
                id = docId,
                createdAt = System.currentTimeMillis(),
                createdBy = auth.currentUser?.email ?: "admin"
            )
            firestore.collection("lessons").document(docId).set(newLesson).await()
            logActivity("إنشاء حصة أونلاين", "تمت إضافة حصة: ${lesson.title}")

            // Also create notification
            val notif = AppNotification(
                id = UUID.randomUUID().toString(),
                targetUid = "all",
                title = "حصة جديدة مجدولة: ${lesson.title}",
                body = "موعد الحصة: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(lesson.dateTimeMillis))}",
                type = "lesson",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notif.id).set(notif).await()

            Result.success(docId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateLesson(lesson: Lesson): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("lessons").document(lesson.id).set(lesson).await()
            logActivity("تعديل حصة", "تم تحديث بيانات الحصة: ${lesson.title}")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteLesson(lessonId: String): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("lessons").document(lessonId).delete().await()
            logActivity("حذف حصة", "تم حذف الحصة رقم $lessonId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAttendanceForLesson(lessonId: String): List<AttendanceRecord> {
        requireAdminId()
        return try {
            firestore.collection("attendanceRecords")
                .whereEqualTo("lessonId", lessonId)
                .get().await()
                .toObjects(AttendanceRecord::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun recordAttendance(
        lessonId: String,
        lessonTitle: String,
        studentUid: String,
        studentCode: String,
        studentName: String,
        status: String
    ): Result<Unit> {
        requireAdminId()
        return try {
            val recordId = "${lessonId}_${studentUid}"
            val record = AttendanceRecord(
                id = recordId,
                lessonId = lessonId,
                lessonTitle = lessonTitle,
                studentUid = studentUid,
                studentCode = studentCode,
                studentName = studentName,
                status = status,
                recordedAt = System.currentTimeMillis(),
                recordedBy = auth.currentUser?.email ?: "admin"
            )
            firestore.collection("attendanceRecords").document(recordId).set(record).await()
            logActivity("تسجيل حضور", "تم تسجيل $status للطالب $studentName في حصة $lessonTitle")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // EXAMINATION SYSTEM
    // ----------------------------------------------------
    suspend fun getAllExaminations(): List<Exam> {
        requireAdminId()
        return try {
            firestore.collection("examinations")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(Exam::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun createExamination(
        exam: Exam,
        questions: List<ExamQuestion>,
        answerKeys: List<ExamAnswerKey>
    ): Result<String> {
        requireAdminId()
        return try {
            val examId = if (exam.id.isNotBlank()) exam.id else UUID.randomUUID().toString()
            val newExam = exam.copy(
                id = examId,
                questionsCount = questions.size,
                createdAt = System.currentTimeMillis(),
                createdBy = auth.currentUser?.email ?: "admin"
            )

            // Save exam
            firestore.collection("examinations").document(examId).set(newExam).await()

            // Save questions
            for (q in questions) {
                val qId = if (q.id.isNotBlank()) q.id else UUID.randomUUID().toString()
                val qObj = q.copy(id = qId, examId = examId)
                firestore.collection("examinationQuestions").document(qId).set(qObj).await()
            }

            // Save answer keys in PRIVATE collection
            for (key in answerKeys) {
                val kId = "${examId}_${key.questionId}"
                val keyObj = key.copy(examId = examId)
                firestore.collection("examAnswerKeys").document(kId).set(keyObj).await()
            }

            logActivity("إنشاء امتحان", "تم إنشاء امتحان جديد: ${exam.title}")

            if (newExam.isPublished) {
                val notif = AppNotification(
                    id = UUID.randomUUID().toString(),
                    targetUid = "all",
                    title = "امتحان جديد متاح: ${exam.title}",
                    body = "مادة: ${exam.subjectName} - الدرجة الكلية: ${exam.totalGrade}",
                    type = "exam",
                    createdAt = System.currentTimeMillis()
                )
                firestore.collection("notifications").document(notif.id).set(notif).await()
            }

            Result.success(examId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun togglePublishExam(examId: String, isPublished: Boolean): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("examinations").document(examId)
                .update("isPublished", isPublished).await()
            logActivity("نشر امتحان", "تغيير حالة نشر الامتحان $examId إلى $isPublished")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteExam(examId: String): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("examinations").document(examId).delete().await()
            logActivity("حذف امتحان", "تم حذف الامتحان $examId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getExamQuestions(examId: String): List<ExamQuestion> {
        return try {
            firestore.collection("examinationQuestions")
                .whereEqualTo("examId", examId)
                .get().await()
                .toObjects(ExamQuestion::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getExamAnswerKeys(examId: String): Map<String, String> {
        requireAdminId()
        return try {
            val snap = firestore.collection("examAnswerKeys")
                .whereEqualTo("examId", examId)
                .get().await()
            snap.documents.associate {
                (it.getString("questionId") ?: "") to (it.getString("correctAnswer") ?: "")
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    suspend fun getSubmissionsForExam(examId: String): List<ExamSubmission> {
        requireAdminId()
        return try {
            firestore.collection("examinationSubmissions")
                .whereEqualTo("examId", examId)
                .get().await()
                .toObjects(ExamSubmission::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAllSubmissions(): List<ExamSubmission> {
        requireAdminId()
        return try {
            firestore.collection("examinationSubmissions")
                .orderBy("submittedAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(ExamSubmission::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getExamGrades(): List<ExamGrade> {
        requireAdminId()
        return try {
            firestore.collection("examinationGrades")
                .orderBy("gradedAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(ExamGrade::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun gradeSubmission(
        submission: ExamSubmission,
        exam: Exam,
        manualScores: Map<String, Double> = emptyMap(),
        feedback: String = ""
    ): Result<ExamGrade> {
        requireAdminId()
        return try {
            val questions = getExamQuestions(submission.examId)
            val answerKeys = getExamAnswerKeys(submission.examId)

            var calculatedScore = 0.0
            for (q in questions) {
                if (manualScores.containsKey(q.id)) {
                    calculatedScore += (manualScores[q.id] ?: 0.0)
                } else {
                    val correct = answerKeys[q.id]?.trim()
                    val studentAnswer = submission.answers[q.id]?.trim()
                    if (correct != null && studentAnswer != null && correct.equals(studentAnswer, ignoreCase = true)) {
                        calculatedScore += q.points
                    }
                }
            }

            val gradeId = "${submission.examId}_${submission.studentUid}"
            val grade = ExamGrade(
                id = gradeId,
                submissionId = submission.id,
                examId = submission.examId,
                studentUid = submission.studentUid,
                studentCode = submission.studentCode,
                studentName = submission.studentName,
                score = calculatedScore,
                totalScore = exam.totalGrade,
                isPassed = calculatedScore >= exam.passingGrade,
                feedback = feedback,
                gradedBy = auth.currentUser?.email ?: "admin",
                gradedAt = System.currentTimeMillis()
            )

            // Save grade to protected collection
            firestore.collection("examinationGrades").document(gradeId).set(grade).await()

            // Update submission status
            firestore.collection("examinationSubmissions").document(submission.id)
                .update("status", ExamSubmission.STATUS_GRADED).await()

            logActivity("تصحيح امتحان", "تم تسجيل درجة $calculatedScore/${exam.totalGrade} للطالب ${submission.studentName}")
            Result.success(grade)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // CURRICULUM MANAGEMENT ("إدارة المناهج")
    // ----------------------------------------------------
    suspend fun getAllCurricula(): List<CurriculumItem> {
        return try {
            firestore.collection("curricula")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(CurriculumItem::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun createCurriculum(item: CurriculumItem): Result<String> {
        requireAdminId()
        return try {
            val docId = UUID.randomUUID().toString()
            val newItem = item.copy(id = docId, createdAt = System.currentTimeMillis())
            firestore.collection("curricula").document(docId).set(newItem).await()
            logActivity("إضافة محتوى تعليمي", "تم نشر مادة جديدة: ${item.title}")

            val notif = AppNotification(
                id = UUID.randomUUID().toString(),
                targetUid = "all",
                title = "محتوى تعليمي جديد: ${item.title}",
                body = "مادة: ${item.subjectName} - ${item.unitName}",
                type = "curriculum",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notif.id).set(notif).await()

            Result.success(docId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteCurriculum(itemId: String): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("curricula").document(itemId).delete().await()
            logActivity("حذف محتوى تعليمي", "تم حذف المادة التعليمية رقم $itemId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // STUDENT EXPENSES AND PAYMENTS
    // ----------------------------------------------------
    suspend fun getAllFees(): List<StudentFee> {
        requireAdminId()
        return try {
            firestore.collection("studentFees")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(StudentFee::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAllPayments(): List<PaymentRecord> {
        requireAdminId()
        return try {
            firestore.collection("paymentRecords")
                .orderBy("paymentDateMillis", Query.Direction.DESCENDING)
                .get().await()
                .toObjects(PaymentRecord::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun addStudentFee(fee: StudentFee): Result<String> {
        requireAdminId()
        return try {
            val docId = UUID.randomUUID().toString()
            val newFee = fee.copy(
                id = docId,
                createdAt = System.currentTimeMillis(),
                createdBy = auth.currentUser?.email ?: "admin"
            )
            firestore.collection("studentFees").document(docId).set(newFee).await()
            logActivity("إضافة مصروفات", "تمت إضافة مطالبة مالية بمبلغ ${fee.amount} ج.م للطالب ${fee.studentName}")

            val notif = AppNotification(
                id = UUID.randomUUID().toString(),
                targetUid = fee.studentUid,
                title = "مطالبة مالية جديدة: ${fee.title}",
                body = "المبلغ المطلوب: ${fee.amount} ج.م - تاريخ الاستحقاق: ${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(fee.dueDateMillis))}",
                type = "fee",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notif.id).set(notif).await()

            Result.success(docId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordPayment(payment: PaymentRecord): Result<String> {
        requireAdminId()
        return try {
            val docId = UUID.randomUUID().toString()
            val newPayment = payment.copy(
                id = docId,
                createdAt = System.currentTimeMillis(),
                recordedBy = auth.currentUser?.email ?: "admin"
            )
            firestore.collection("paymentRecords").document(docId).set(newPayment).await()
            logActivity("تسجيل دفعة مالية", "تم تسجيل سداد بمبلغ ${payment.amount} ج.م بطريقة ${payment.paymentMethod} للطالب ${payment.studentName}")

            val notif = AppNotification(
                id = UUID.randomUUID().toString(),
                targetUid = payment.studentUid,
                title = "تم تأكيد استلام دفعة مالية",
                body = "تم سداد مبلغ ${payment.amount} ج.م بنجاح برقم إيصال ${payment.referenceNumber.ifBlank { docId.take(8) }}",
                type = "fee",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notif.id).set(notif).await()

            Result.success(docId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getStudentFinancialSummaries(): List<StudentFinancialSummary> {
        requireAdminId()
        return try {
            val students = getAllStudents()
            val fees = getAllFees()
            val payments = getAllPayments()

            students.map { student ->
                val studentFeesSum = fees.filter { it.studentUid == student.uid }.sumOf { it.amount }
                val studentPaidSum = payments.filter { it.studentUid == student.uid }.sumOf { it.amount }
                val remaining = (studentFeesSum - studentPaidSum).coerceAtLeast(0.0)

                val status = when {
                    studentFeesSum == 0.0 -> "لا توجد رسوم"
                    studentPaidSum >= studentFeesSum -> "مسدد بالكامل"
                    studentPaidSum > 0.0 -> "مسدد جزئياً"
                    else -> "غير مسدد"
                }

                StudentFinancialSummary(
                    studentUid = student.uid,
                    studentCode = student.studentCode,
                    studentName = student.fullName,
                    totalFees = studentFeesSum,
                    totalPaid = studentPaidSum,
                    remainingBalance = remaining,
                    paymentStatus = status
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ----------------------------------------------------
    // NOTIFICATIONS
    // ----------------------------------------------------
    suspend fun sendAnnouncement(title: String, body: String, targetUid: String = "all"): Result<Unit> {
        requireAdminId()
        return try {
            val notif = AppNotification(
                id = UUID.randomUUID().toString(),
                targetUid = targetUid,
                title = title.trim(),
                body = body.trim(),
                type = "announcement",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notif.id).set(notif).await()
            logActivity("إرسال إشعار عام", "تم إرسال إشعار: $title")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // SETTINGS
    // ----------------------------------------------------
    suspend fun getAppSettings(): AppSettings {
        return try {
            val doc = firestore.collection("applicationSettings").document("main").get().await()
            if (doc.exists()) doc.toObject(AppSettings::class.java) ?: AppSettings() else AppSettings()
        } catch (e: Exception) {
            AppSettings()
        }
    }

    suspend fun updateAppSettings(settings: AppSettings): Result<Unit> {
        requireAdminId()
        return try {
            firestore.collection("applicationSettings").document("main").set(settings).await()
            logActivity("تحديث الإعدادات", "تم تعديل إعدادات المنصة")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
