package com.example.data.model

data class StudentFee(
    val id: String = "",
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val title: String = "",
    val amount: Double = 0.0,
    val dueDateMillis: Long = System.currentTimeMillis() + (30 * 24 * 60 * 60 * 1000L),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = ""
)

data class PaymentRecord(
    val id: String = "",
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val feeId: String = "",
    val amount: Double = 0.0,
    val paymentDateMillis: Long = System.currentTimeMillis(),
    val paymentMethod: String = METHOD_CASH, // "كاش", "تحويل بنكي", "بطاقة ائتمان", "فودافون كاش"
    val referenceNumber: String = "",
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val METHOD_CASH = "كاش"
        const val METHOD_BANK_TRANSFER = "تحويل بنكي"
        const val METHOD_CREDIT_CARD = "بطاقة ائتمان"
        const val METHOD_VODAFONE_CASH = "فودافون كاش"
    }
}

data class StudentFinancialSummary(
    val studentUid: String = "",
    val studentCode: String = "",
    val studentName: String = "",
    val totalFees: Double = 0.0,
    val totalPaid: Double = 0.0,
    val remainingBalance: Double = 0.0,
    val paymentStatus: String = "غير مسدد" // "مسدد بالكامل", "مسدد جزئياً", "غير مسدد"
)
