package com.example.data.repository

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.StudentCode
import com.example.data.model.User
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthRepository(private val context: Context) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirestoreHelper.getFirestore(context)
    private val credentialManager: CredentialManager = CredentialManager.create(context)

    companion object {
        private const val TAG = "AuthRepository"
        val ADMIN_ACCOUNTS = mapOf(
            "ozilziad24@gmail.com" to "زياد الطنساوي",
            "zt067313@gmail.com" to "ندي الطنساوي"
        )

        fun getAdminNameForEmail(email: String?): String? {
            if (email == null) return null
            return ADMIN_ACCOUNTS[email.trim().lowercase()]
        }
    }

    val currentFirebaseUser get() = auth.currentUser

    fun observeCurrentUser(): Flow<User?> = callbackFlow {
        val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val fbUser = firebaseAuth.currentUser
            if (fbUser == null) {
                trySend(null)
            } else {
                // Listen to Firestore user doc
                val registration = firestore.collection("users").document(fbUser.uid)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e(TAG, "Error fetching user doc: ${error.message}")
                            return@addSnapshotListener
                        }
                        val adminName = getAdminNameForEmail(fbUser.email)
                        val isAdminUser = adminName != null

                        if (snapshot != null && snapshot.exists()) {
                            var user = snapshot.toObject(User::class.java)!!
                            // Ensure only the two designated accounts hold admin role
                            if (isAdminUser && (user.role != User.ROLE_ADMIN || user.accountStatus != User.STATUS_ACTIVE || user.fullName.isBlank())) {
                                user = user.copy(
                                    role = User.ROLE_ADMIN,
                                    accountStatus = User.STATUS_ACTIVE,
                                    fullName = user.fullName.ifBlank { adminName }
                                )
                                firestore.collection("users").document(fbUser.uid).set(user)
                            } else if (!isAdminUser && user.role == User.ROLE_ADMIN) {
                                user = user.copy(role = User.ROLE_STUDENT)
                                firestore.collection("users").document(fbUser.uid).set(user)
                            }
                            trySend(user)
                        } else {
                            // User authenticated but doc not yet synced, send minimal user
                            val minimalUser = User(
                                uid = fbUser.uid,
                                email = fbUser.email ?: "",
                                fullName = adminName ?: (fbUser.displayName ?: ""),
                                role = if (isAdminUser) User.ROLE_ADMIN else User.ROLE_STUDENT,
                                accountStatus = if (isAdminUser) User.STATUS_ACTIVE else User.STATUS_PENDING
                            )
                            trySend(minimalUser)
                        }
                    }
                // ensure we remove listener when flow closes
            }
        }

        auth.addAuthStateListener(authListener)
        awaitClose {
            auth.removeAuthStateListener(authListener)
        }
    }

    suspend fun signInWithGoogle(): Result<User> {
        return try {
            val serverClientId = context.getString(R.string.default_web_client_id)
            val googleIdOption = GetSignInWithGoogleOption.Builder(serverClientId)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(context, request)
            val credential = result.credential

            if (credential is androidx.credentials.CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken

                val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val firebaseUser = authResult.user ?: throw Exception("تعذر استرجاع بيانات المستخدم من Google")

                // Check or create Firestore document
                val userDocRef = firestore.collection("users").document(firebaseUser.uid)
                val snapshot = userDocRef.get().await()

                val adminName = getAdminNameForEmail(firebaseUser.email)
                val isAdminUser = adminName != null

                val user = if (snapshot.exists()) {
                    var existingUser = snapshot.toObject(User::class.java)!!
                    if (isAdminUser) {
                        existingUser = existingUser.copy(
                            role = User.ROLE_ADMIN,
                            accountStatus = User.STATUS_ACTIVE,
                            fullName = if (existingUser.fullName.isBlank()) adminName else existingUser.fullName
                        )
                        userDocRef.set(existingUser).await()
                    } else if (existingUser.role == User.ROLE_ADMIN) {
                        existingUser = existingUser.copy(role = User.ROLE_STUDENT)
                        userDocRef.set(existingUser).await()
                    }
                    existingUser
                } else {
                    val newUser = User(
                        uid = firebaseUser.uid,
                        email = firebaseUser.email ?: "",
                        fullName = adminName ?: (firebaseUser.displayName ?: ""),
                        role = if (isAdminUser) User.ROLE_ADMIN else User.ROLE_STUDENT,
                        accountStatus = if (isAdminUser) User.STATUS_ACTIVE else User.STATUS_PENDING,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                    userDocRef.set(newUser).await()
                    newUser
                }

                Result.success(user)
            } else {
                Result.failure(Exception("نوع تسجيل الدخول غير مدعوم"))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google sign-in cancelled by user")
            Result.failure(Exception("تم إلغاء تسجيل الدخول"))
        } catch (e: Exception) {
            Log.e(TAG, "Sign in failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun updateFullName(fullName: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(Exception("المستخدم غير مسجل"))
        return try {
            firestore.collection("users").document(uid)
                .update(
                    mapOf(
                        "fullName" to fullName.trim(),
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun activateStudentCode(inputCode: String): Result<String> {
        val uid = auth.currentUser?.uid ?: return Result.failure(Exception("المستخدم غير مسجل"))
        val trimmedCode = inputCode.trim().uppercase()

        if (trimmedCode.isBlank()) {
            return Result.failure(Exception("يرجى إدخال كود الطالب"))
        }

        return try {
            // Check code existence
            val codeQuery = firestore.collection("studentCodes")
                .whereEqualTo("code", trimmedCode)
                .get()
                .await()

            if (codeQuery.isEmpty) {
                return Result.failure(Exception("كود الطالب غير صحيح، يرجى مراجعة إدارة المنصة"))
            }

            val codeDoc = codeQuery.documents.first()
            val studentCodeObj = codeDoc.toObject(StudentCode::class.java)
                ?: return Result.failure(Exception("خطأ في قراءة بيانات الكود"))

            if (studentCodeObj.status == StudentCode.STATUS_ACTIVE) {
                if (studentCodeObj.studentUid == uid) {
                    return Result.success("تم تفعيل هذا الكود مسبقاً لحسابك")
                }
                return Result.failure(Exception("هذا الكود مستخدم بالفعل من قبل حساب آخر ولا يمكن استخدامه مجدداً"))
            }

            if (studentCodeObj.status == StudentCode.STATUS_REVOKED) {
                return Result.failure(Exception("هذا الكود ملغى أو منتهي الصلاحية، يرجى مراجعة الإدارة"))
            }

            val currentUserDoc = firestore.collection("users").document(uid).get().await()
            val currentUser = currentUserDoc.toObject(User::class.java)

            // Update student code record
            val updatedCode = studentCodeObj.copy(
                status = StudentCode.STATUS_ACTIVE,
                studentUid = uid,
                studentEmail = currentUser?.email ?: auth.currentUser?.email ?: "",
                studentName = currentUser?.fullName ?: auth.currentUser?.displayName ?: "",
                activatedAt = System.currentTimeMillis()
            )
            codeDoc.reference.set(updatedCode).await()

            // Update user document to active status and link code
            firestore.collection("users").document(uid).update(
                mapOf(
                    "studentCode" to trimmedCode,
                    "accountStatus" to User.STATUS_ACTIVE,
                    "className" to studentCodeObj.assignedClass,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()

            Result.success("تم تفعيل حسابك بنجاح! مرحباً بك في المنصة")
        } catch (e: Exception) {
            Log.e(TAG, "Code activation failed: ${e.message}", e)
            Result.failure(Exception("فشل تفعيل الكود: ${e.message}"))
        }
    }

    fun signOut() {
        auth.signOut()
    }
}
