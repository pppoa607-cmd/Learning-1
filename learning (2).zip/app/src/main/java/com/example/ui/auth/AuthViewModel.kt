package com.example.ui.auth

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.User
import com.example.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class NeedsName(val user: User) : AuthUiState()
    data class PendingActivation(val user: User) : AuthUiState()
    data class Authenticated(val user: User) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepository = AuthRepository(application)

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.observeCurrentUser().collect { user ->
                _currentUser.value = user
                when {
                    user == null -> _uiState.value = AuthUiState.Idle
                    user.fullName.isBlank() -> _uiState.value = AuthUiState.NeedsName(user)
                    user.isAdmin -> _uiState.value = AuthUiState.Authenticated(user)
                    user.isStudent && user.accountStatus != User.STATUS_ACTIVE -> {
                        _uiState.value = AuthUiState.PendingActivation(user)
                    }
                    else -> _uiState.value = AuthUiState.Authenticated(user)
                }
            }
        }
    }

    fun signInWithGoogle() {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val result = authRepository.signInWithGoogle()
            result.onSuccess { user ->
                when {
                    user.fullName.isBlank() -> _uiState.value = AuthUiState.NeedsName(user)
                    user.isAdmin -> _uiState.value = AuthUiState.Authenticated(user)
                    user.accountStatus != User.STATUS_ACTIVE -> _uiState.value = AuthUiState.PendingActivation(user)
                    else -> _uiState.value = AuthUiState.Authenticated(user)
                }
            }.onFailure { error ->
                _uiState.value = AuthUiState.Error(error.message ?: "حدث خطأ أثناء تسجيل الدخول")
            }
        }
    }

    fun submitFullName(name: String) {
        if (name.trim().isBlank()) {
            _uiState.value = AuthUiState.Error("يرجى إدخال الاسم بالكامل")
            return
        }
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            authRepository.updateFullName(name).onSuccess {
                val current = _currentUser.value?.copy(fullName = name.trim())
                if (current != null) {
                    _currentUser.value = current
                    if (current.isAdmin || current.accountStatus == User.STATUS_ACTIVE) {
                        _uiState.value = AuthUiState.Authenticated(current)
                    } else {
                        _uiState.value = AuthUiState.PendingActivation(current)
                    }
                }
            }.onFailure {
                _uiState.value = AuthUiState.Error(it.message ?: "فشل حفظ الاسم")
            }
        }
    }

    fun activateCode(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.activateStudentCode(code)
            result.onSuccess { message ->
                onResult(true, message)
            }.onFailure { error ->
                onResult(false, error.message ?: "فشل تفعيل الكود")
            }
        }
    }

    fun signOut() {
        authRepository.signOut()
        _currentUser.value = null
        _uiState.value = AuthUiState.Idle
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error) {
            _uiState.value = AuthUiState.Idle
        }
    }
}
