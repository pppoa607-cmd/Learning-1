package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.components.RtlProvider
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMainScreen(
    adminUser: User,
    viewModel: AdminViewModel,
    onSignOut: () -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    RtlProvider {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لوحة إدارة Learning",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = adminUser.fullName.ifBlank { adminUser.email },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 4.dp)
                    ) {
                        AdminTab.values().forEach { tab ->
                            val isSelected = selectedTab == tab
                            val icon = when (tab) {
                                AdminTab.DASHBOARD -> Icons.Default.Dashboard
                                AdminTab.STUDENTS -> Icons.Default.People
                                AdminTab.CODES -> Icons.Default.VpnKey
                                AdminTab.LESSONS -> Icons.Default.VideoCameraFront
                                AdminTab.ATTENDANCE -> Icons.Default.FactCheck
                                AdminTab.EXAMS -> Icons.Default.Assignment
                                AdminTab.SUBMISSIONS -> Icons.Default.AssignmentTurnedIn
                                AdminTab.GRADES -> Icons.Default.Grade
                                AdminTab.CURRICULUM -> Icons.AutoMirrored.Filled.MenuBook
                                AdminTab.FINANCIAL -> Icons.Default.AccountBalanceWallet
                                AdminTab.REPORTS -> Icons.Default.Assessment
                                AdminTab.LOGS -> Icons.Default.History
                                AdminTab.SETTINGS -> Icons.Default.Settings
                            }

                            NavigationDrawerItem(
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(tab.title) },
                                selected = isSelected,
                                onClick = {
                                    viewModel.selectTab(tab)
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier
                                    .padding(horizontal = 12.dp, vertical = 2.dp)
                                    .testTag("admin_nav_${tab.name.lowercase()}")
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        NavigationDrawerItem(
                            icon = { Icon(Icons.Default.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            label = { Text("تسجيل الخروج", color = MaterialTheme.colorScheme.error) },
                            selected = false,
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                    onSignOut()
                                }
                            },
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .testTag("admin_sign_out")
                        )
                    }
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = selectedTab.title,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "القائمة")
                            }
                        },
                        actions = {
                            IconButton(onClick = { viewModel.loadAllData() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "تحديث")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedTab) {
                        AdminTab.DASHBOARD -> AdminDashboardContent(viewModel, onNavigateTab = { viewModel.selectTab(it) })
                        AdminTab.STUDENTS -> AdminStudentsScreen(viewModel)
                        AdminTab.CODES -> AdminCodesScreen(viewModel)
                        AdminTab.LESSONS -> AdminLessonsScreen(viewModel)
                        AdminTab.ATTENDANCE -> AdminAttendanceScreen(viewModel)
                        AdminTab.EXAMS -> AdminExamsScreen(viewModel)
                        AdminTab.SUBMISSIONS -> AdminSubmissionsScreen(viewModel)
                        AdminTab.GRADES -> AdminGradesScreen(viewModel)
                        AdminTab.CURRICULUM -> AdminCurriculumScreen(viewModel)
                        AdminTab.FINANCIAL -> AdminFinancialScreen(viewModel)
                        AdminTab.REPORTS -> AdminReportsScreen(viewModel)
                        AdminTab.LOGS -> AdminLogsScreen(viewModel)
                        AdminTab.SETTINGS -> AdminSettingsScreen(viewModel)
                    }

                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDashboardContent(
    viewModel: AdminViewModel,
    onNavigateTab: (AdminTab) -> Unit
) {
    val stats by viewModel.stats.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Hero Welcome Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "مرحباً بك في المركز الإداري للمنصة",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "إحصائيات فورية حول أداء الطلاب، الحصص، الامتحانات، والإيرادات المالية",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        SectionHeader(title = "نظرة عامة على الطلاب")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "إجمالي الطلاب",
                value = stats.totalStudents.toString(),
                icon = Icons.Default.People,
                iconTint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "الطلاب النشطون",
                value = stats.activeStudents.toString(),
                icon = Icons.Default.CheckCircle,
                iconTint = Color(0xFF16A34A),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "الحسابات المعلقة",
                value = stats.suspendedStudents.toString(),
                icon = Icons.Default.PauseCircle,
                iconTint = Color(0xFFDC2626),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "حضور الطلاب",
                value = "${stats.attendancePresentCount} طالب",
                icon = Icons.Default.FactCheck,
                iconTint = Color(0xFF0D9488),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        SectionHeader(title = "الحصص والامتحانات")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "الحصص المجدولة",
                value = "${stats.upcomingLessons} حصة",
                icon = Icons.Default.VideoCameraFront,
                iconTint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "إجمالي الامتحانات",
                value = stats.totalExaminations.toString(),
                icon = Icons.Default.Assignment,
                iconTint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        StatCard(
            title = "تسليمات بانتظار المراجعة",
            value = "${stats.pendingSubmissions} تسليم",
            icon = Icons.Default.HourglassTop,
            iconTint = Color(0xFFD97706),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        SectionHeader(title = "الملخص المالي والمدفوعات")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "المحصل الفعلي",
                value = "${stats.totalCollectedPayments.toInt()} ج.م",
                icon = Icons.Default.Payments,
                iconTint = Color(0xFF16A34A),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "المتبقي غير المسدد",
                value = "${stats.outstandingBalances.toInt()} ج.م",
                icon = Icons.Default.AccountBalanceWallet,
                iconTint = Color(0xFFDC2626),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        SectionHeader(title = "إجراءات سريعة")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { onNavigateTab(AdminTab.CODES) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("توليد كود")
            }
            FilledTonalButton(
                onClick = { onNavigateTab(AdminTab.LESSONS) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة حصة")
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(
                onClick = { onNavigateTab(AdminTab.EXAMS) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إنشاء امتحان")
            }
            FilledTonalButton(
                onClick = { onNavigateTab(AdminTab.FINANCIAL) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تسجيل دفعة")
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}
