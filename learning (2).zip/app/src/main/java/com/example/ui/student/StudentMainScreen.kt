package com.example.ui.student

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.User
import com.example.ui.components.RtlProvider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentMainScreen(
    studentUser: User,
    viewModel: StudentViewModel,
    onSignOut: () -> Unit
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val activeExam by viewModel.activeExam.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    RtlProvider {
        if (activeExam != null) {
            // Exam taking flow full-screen
            ExamTakingScreen(
                exam = activeExam!!,
                viewModel = viewModel,
                onExit = { viewModel.exitExam() }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = selectedTab.title,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        },
                        actions = {
                            IconButton(onClick = { viewModel.loadData() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "تحديث")
                            }
                            IconButton(onClick = onSignOut) {
                                Icon(Icons.Default.ExitToApp, contentDescription = "تسجيل الخروج")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        val bottomTabs = listOf(
                            StudentTab.HOME,
                            StudentTab.LESSONS,
                            StudentTab.EXAMS,
                            StudentTab.CURRICULUM,
                            StudentTab.FINANCIAL
                        )

                        bottomTabs.forEach { tab ->
                            val isSelected = selectedTab == tab
                            val icon = when (tab) {
                                StudentTab.HOME -> Icons.Default.Home
                                StudentTab.LESSONS -> Icons.Default.VideoCameraFront
                                StudentTab.EXAMS -> Icons.Default.Assignment
                                StudentTab.CURRICULUM -> Icons.AutoMirrored.Filled.MenuBook
                                StudentTab.FINANCIAL -> Icons.Default.AccountBalanceWallet
                                else -> Icons.Default.Circle
                            }

                            NavigationBarItem(
                                icon = { Icon(icon, contentDescription = tab.title) },
                                label = { Text(tab.title) },
                                selected = isSelected,
                                onClick = { viewModel.selectTab(tab) },
                                modifier = Modifier.testTag("student_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedTab) {
                        StudentTab.HOME -> StudentHomeScreen(studentUser, viewModel, onNavigate = { viewModel.selectTab(it) })
                        StudentTab.LESSONS -> StudentLessonsScreen(viewModel)
                        StudentTab.EXAMS -> StudentExamsScreen(viewModel)
                        StudentTab.CURRICULUM -> StudentCurriculumScreen(viewModel)
                        StudentTab.ATTENDANCE -> StudentAttendanceScreen(viewModel)
                        StudentTab.FINANCIAL -> StudentFinancialScreen(viewModel)
                        StudentTab.NOTIFICATIONS -> StudentNotificationsScreen(viewModel)
                        StudentTab.PROFILE -> StudentProfileScreen(studentUser, onSignOut)
                    }

                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 16.dp)
                        )
                    }
                }
            }
        }
    }
}
