package com.example.ui.admin

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.EmptyState
import com.example.ui.components.StatusBadge
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminCurriculumScreen(viewModel: AdminViewModel) {
    val curricula by viewModel.curricula.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "إدارة المناهج والمواد الدراسية (${curricula.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Button(
                onClick = { showCreateDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("add_curriculum_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة مادة")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (curricula.isEmpty()) {
            EmptyState(
                icon = Icons.AutoMirrored.Filled.MenuBook,
                title = "لا توجد مواد تعليمية مضافة",
                message = "قم بإضافة مذكرات PDF، فيديوهات تعليمية، وشروحات للمناهج الدراسية",
                actionButton = {
                    Button(onClick = { showCreateDialog = true }) { Text("إضافة محتوى") }
                }
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(curricula, key = { it.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${item.subjectName} • ${item.unitName} - ${item.chapterName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { viewModel.deleteCurriculum(item.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                }
                            }

                            if (item.description.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "نوع الملف: ${item.fileType.uppercase()} | الرابط: ${item.fileUrl.ifBlank { "مرفق داخلي" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateCurriculumDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { newItem ->
                viewModel.createCurriculum(newItem) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) showCreateDialog = false
                }
            }
        )
    }
}

@Composable
fun CreateCurriculumDialog(
    onDismiss: () -> Unit,
    onCreate: (CurriculumItem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subjectName by remember { mutableStateOf("اللغة الإنجليزية") }
    var unitName by remember { mutableStateOf("الوحدة الأولى") }
    var chapterName by remember { mutableStateOf("الدرس الأول") }
    var description by remember { mutableStateOf("") }
    var fileUrl by remember { mutableStateOf("https://drive.google.com/") }
    var fileType by remember { mutableStateOf("pdf") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة محتوى تعليمي للمنهج") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الدرس / المذكرة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("المادة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = unitName,
                        onValueChange = { unitName = it },
                        label = { Text("الوحدة") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = chapterName,
                        onValueChange = { chapterName = it },
                        label = { Text("الفصل") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = fileUrl,
                    onValueChange = { fileUrl = it },
                    label = { Text("رابط ملف PDF أو الفيديو") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("وصف توضيحي") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val item = CurriculumItem(
                            title = title.trim(),
                            subjectName = subjectName.trim(),
                            unitName = unitName.trim(),
                            chapterName = chapterName.trim(),
                            description = description.trim(),
                            fileUrl = fileUrl.trim(),
                            fileType = fileType
                        )
                        onCreate(item)
                    }
                },
                enabled = title.isNotBlank()
            ) { Text("إضافة ونشر") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdminFinancialScreen(viewModel: AdminViewModel) {
    val summaries by viewModel.financialSummaries.collectAsState()
    val students by viewModel.students.collectAsState()
    var showAddFeeDialog by remember { mutableStateOf(false) }
    var showRecordPaymentDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "المصاريف والمدفوعات",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "متابعة الرسوم المحصلة والرصيد المتبقي بدقة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { showAddFeeDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة رسوم", fontSize = 12.sp)
                }

                Button(
                    onClick = { showRecordPaymentDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تسجيل سداد", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (summaries.isEmpty()) {
            EmptyState(
                icon = Icons.Default.AccountBalanceWallet,
                title = "لا توجد سجلات مالية",
                message = "قم بإضافة رسوم دراسية وتسجيل دفعات الطلاب للبدء بحساب الأرصدة"
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(summaries, key = { it.studentUid }) { summary ->
                    FinancialSummaryCard(summary = summary)
                }
            }
        }
    }

    if (showAddFeeDialog) {
        AddFeeDialog(
            students = students,
            onDismiss = { showAddFeeDialog = false },
            onAdd = { fee ->
                viewModel.addFee(fee) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) showAddFeeDialog = false
                }
            }
        )
    }

    if (showRecordPaymentDialog) {
        RecordPaymentDialog(
            students = students,
            onDismiss = { showRecordPaymentDialog = false },
            onRecord = { payment ->
                viewModel.recordPayment(payment) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) showRecordPaymentDialog = false
                }
            }
        )
    }
}

@Composable
fun FinancialSummaryCard(summary: StudentFinancialSummary) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = summary.studentName.ifBlank { "طالب" },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "كود الطالب: ${summary.studentCode.ifBlank { "غير مربوط" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                StatusBadge(status = summary.paymentStatus)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "إجمالي الرسوم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "${summary.totalFees.toInt()} ج.م", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }

                Column {
                    Text(text = "المبلغ المسدد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${summary.totalPaid.toInt()} ج.م",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                    )
                }

                Column {
                    Text(text = "الرصيد المتبقي", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${summary.remainingBalance.toInt()} ج.م",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (summary.remainingBalance > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AddFeeDialog(
    students: List<User>,
    onDismiss: () -> Unit,
    onAdd: (StudentFee) -> Unit
) {
    var selectedStudentUid by remember { mutableStateOf(students.firstOrNull()?.uid ?: "") }
    var title by remember { mutableStateOf("مصاريف الفصل الدراسي") }
    var amount by remember { mutableStateOf("500") }

    val student = students.find { it.uid == selectedStudentUid }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مطالبة رسوم للطالب") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (students.isNotEmpty()) {
                    Text(text = "اختر الطالب:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.height(100.dp)) {
                        items(students) { st ->
                            TextButton(
                                onClick = { selectedStudentUid = st.uid },
                                colors = ButtonDefaults.textButtonColors(
                                    containerColor = if (st.uid == selectedStudentUid) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(st.fullName.ifBlank { st.email })
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("بند المصروفات") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ بالجنية المصري") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (student != null) {
                        val fee = StudentFee(
                            studentUid = student.uid,
                            studentCode = student.studentCode,
                            studentName = student.fullName,
                            title = title.trim(),
                            amount = amount.toDoubleOrNull() ?: 0.0
                        )
                        onAdd(fee)
                    }
                },
                enabled = student != null && amount.toDoubleOrNull() != null
            ) { Text("إضافة الرسوم") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun RecordPaymentDialog(
    students: List<User>,
    onDismiss: () -> Unit,
    onRecord: (PaymentRecord) -> Unit
) {
    var selectedStudentUid by remember { mutableStateOf(students.firstOrNull()?.uid ?: "") }
    var amount by remember { mutableStateOf("250") }
    var method by remember { mutableStateOf(PaymentRecord.METHOD_CASH) }
    var notes by remember { mutableStateOf("") }

    val student = students.find { it.uid == selectedStudentUid }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل دفعة سداد لطالب") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (students.isNotEmpty()) {
                    Text(text = "اختر الطالب المسدد:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.height(100.dp)) {
                        items(students) { st ->
                            TextButton(
                                onClick = { selectedStudentUid = st.uid },
                                colors = ButtonDefaults.textButtonColors(
                                    containerColor = if (st.uid == selectedStudentUid) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(st.fullName.ifBlank { st.email })
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ المسدد") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = method,
                    onValueChange = { method = it },
                    label = { Text("طريقة الدفع (كاش / فودافون كاش / تحويل)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("رقم الإيصال / ملاحظات") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (student != null) {
                        val payment = PaymentRecord(
                            studentUid = student.uid,
                            studentCode = student.studentCode,
                            studentName = student.fullName,
                            amount = amount.toDoubleOrNull() ?: 0.0,
                            paymentMethod = method.trim(),
                            notes = notes.trim()
                        )
                        onRecord(payment)
                    }
                },
                enabled = student != null && amount.toDoubleOrNull() != null
            ) { Text("تسجيل السداد") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdminReportsScreen(viewModel: AdminViewModel) {
    val stats by viewModel.stats.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "التقارير التحليلية والأكاديمية",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "مؤشرات أداء المركز التعليمي والتحصيل المالي والالتزام بالحصص",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "مؤشر التحصيل المالي", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val totalFinancial = stats.totalFees
                val collected = stats.totalCollectedPayments
                val rate = if (totalFinancial > 0) ((collected / totalFinancial) * 100).toInt() else 0
                LinearProgressIndicator(
                    progress = { if (totalFinancial > 0) (collected / totalFinancial).toFloat() else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = Color(0xFF16A34A)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "نسبة التحصيل: $rate% (المحصل: ${collected.toInt()} ج.م من أصل ${totalFinancial.toInt()} ج.م)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "مؤشر حضور الطلاب", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val totalAtt = stats.attendancePresentCount + stats.attendanceAbsentCount
                val attRate = if (totalAtt > 0) ((stats.attendancePresentCount.toDouble() / totalAtt) * 100).toInt() else 100
                LinearProgressIndicator(
                    progress = { if (totalAtt > 0) (stats.attendancePresentCount.toFloat() / totalAtt) else 1f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = Color(0xFF0D9488)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "نسبة الحضور: $attRate% (حضر: ${stats.attendancePresentCount} | غاب: ${stats.attendanceAbsentCount})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun AdminLogsScreen(viewModel: AdminViewModel) {
    val logs by viewModel.activityLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "سجل النشاطات الإدارية (${logs.size})",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "سجل تدقيق كامل لجميع العمليات الحساسة التي تمت على النظام",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (logs.isEmpty()) {
            EmptyState(
                icon = Icons.Default.History,
                title = "لا توجد نشاطات مسجلة",
                message = "العمليات الحساسة التي ينفذها المسؤولون ستسجل تلقائياً هنا"
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(logs, key = { it.id }) { log ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = log.actionType, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Text(text = dateStr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = log.description, style = MaterialTheme.typography.bodyMedium)
                            Text(text = "بواسطة: ${log.adminName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSettingsScreen(viewModel: AdminViewModel) {
    var title by remember { mutableStateOf("تنبيه هام للطلاب") }
    var body by remember { mutableStateOf("يرجى تسليم الواجبات والاختبارات قبل الموعد المحدد") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "إعدادات الإدارة والإشعارات العامة",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "إرسال إشعار عام لجميع الطلاب", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الإشعار") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it },
                    label = { Text("نص الإشعار") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.sendAnnouncement(title, body) { success, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إرسال الإشعار لجميع الطلاب")
                }
            }
        }
    }
}
