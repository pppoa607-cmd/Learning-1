package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light educational palette
val EduPrimary = Color(0xFF1E3A8A) // Royal Blue
val EduOnPrimary = Color(0xFFFFFFFF)
val EduPrimaryContainer = Color(0xFFDBEAFE)
val EduOnPrimaryContainer = Color(0xFF1E40AF)

val EduSecondary = Color(0xFFD97706) // Amber / Gold
val EduOnSecondary = Color(0xFFFFFFFF)
val EduSecondaryContainer = Color(0xFFFEF3C7)
val EduOnSecondaryContainer = Color(0xFF92400E)

val EduTertiary = Color(0xFF0D9488) // Teal / Mint
val EduOnTertiary = Color(0xFFFFFFFF)
val EduTertiaryContainer = Color(0xFFCCFBF1)
val EduOnTertiaryContainer = Color(0xFF115E59)

val EduBackground = Color(0xFFF8FAFC)
val EduOnBackground = Color(0xFF0F172A)
val EduSurface = Color(0xFFFFFFFF)
val EduOnSurface = Color(0xFF0F172A)
val EduSurfaceVariant = Color(0xFFF1F5F9)
val EduOnSurfaceVariant = Color(0xFF475569)

// Dark educational palette
val EduPrimaryDark = Color(0xFF60A5FA)
val EduOnPrimaryDark = Color(0xFF002244)
val EduPrimaryContainerDark = Color(0xFF1E3A8A)
val EduOnPrimaryContainerDark = Color(0xFFDBEAFE)

val EduSecondaryDark = Color(0xFFFBBF24)
val EduOnSecondaryDark = Color(0xFF451A03)
val EduSecondaryContainerDark = Color(0xFF78350F)
val EduOnSecondaryContainerDark = Color(0xFFFEF3C7)

val EduTertiaryDark = Color(0xFF2DD4BF)
val EduOnTertiaryDark = Color(0xFF042F2E)
val EduTertiaryContainerDark = Color(0xFF115E59)
val EduOnTertiaryContainerDark = Color(0xFFCCFBF1)

val EduBackgroundDark = Color(0xFF0B1120)
val EduOnBackgroundDark = Color(0xFFF8FAFC)
val EduSurfaceDark = Color(0xFF151E32)
val EduOnSurfaceDark = Color(0xFFF1F5F9)
val EduSurfaceVariantDark = Color(0xFF1E293B)
val EduOnSurfaceVariantDark = Color(0xFF94A3B8)

// Status colors
val StatusPresent = Color(0xFF16A34A)
val StatusAbsent = Color(0xFFDC2626)
val StatusLate = Color(0xFFEA580C)
val StatusUnrecorded = Color(0xFF64748B)
