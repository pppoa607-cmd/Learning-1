package com.example.ui.admin

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.EmptyState
import com.example.ui.components.StatusBadge
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminExamsScreen(viewModel: AdminViewModel) {
    val examinations by viewModel.examinations.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "إدارة الاختبارات والامتحانات (${examinations.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Button(
                onClick = { showCreateDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("create_exam_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إنشاء امتحان")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (examinations.isEmpty()) {
            EmptyState(
                icon = Icons.Default.Assignment,
                title = "لا توجد امتحانات",
                message = "قم بإنشاء امتحان جديد وإضافة الأسئلة ونموذج الإجابة المحمي",
                actionButton = {
                    Button(onClick = { showCreateDialog = true }) {
                        Text("إنشاء امتحان")
                    }
                }
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(examinations, key = { it.id }) { exam ->
                    AdminExamCard(
                        exam = exam,
                        onTogglePublish = { viewModel.togglePublishExam(exam.id, !exam.isPublished) },
                        onDelete = { viewModel.deleteExam(exam.id) }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateExamDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { exam, questions, keys ->
                viewModel.createExam(exam, questions, keys) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) showCreateDialog = false
                }
            }
        )
    }
}

@Composable
fun AdminExamCard(
    exam: Exam,
    onTogglePublish: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = exam.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${exam.subjectName} • ${exam.className}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                StatusBadge(status = if (exam.isPublished) "منشور" else "مسودة")
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "الدرجة الكلية: ${exam.totalGrade.toInt()} | درجة النجاح: ${exam.passingGrade.toInt()} | المدة: ${exam.timeLimitMinutes} دقيقة | الأسئلة: ${exam.questionsCount}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onTogglePublish,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (exam.isPublished) Color(0xFFD97706) else Color(0xFF16A34A)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (exam.isPublished) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (exam.isPublished) "إلغاء النشر" else "نشر للطلاب", fontSize = 12.sp)
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف الامتحان",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
fun CreateExamDialog(
    onDismiss: () -> Unit,
    onCreate: (Exam, List<ExamQuestion>, List<ExamAnswerKey>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subjectName by remember { mutableStateOf("اللغة العربية") }
    var className by remember { mutableStateOf("الصف الأول الثانوي") }
    var totalGrade by remember { mutableStateOf("100") }
    var passingGrade by remember { mutableStateOf("50") }
    var timeLimit by remember { mutableStateOf("45") }
    var isPublished by remember { mutableStateOf(true) }

    // Sample question builder
    var q1Text by remember { mutableStateOf("ما هو إعراب الفاعل في الجملة الفعلية؟") }
    var q1Correct by remember { mutableStateOf("مرفوع دائماً") }

    var q2Text by remember { mutableStateOf("تنقسم الكلمة في اللغة العربية إلى اسم وفعل وحرف؟") }
    var q2Correct by remember { mutableStateOf("صح") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إنشاء وتأمين امتحان جديد") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الامتحان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("المادة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = totalGrade,
                        onValueChange = { totalGrade = it },
                        label = { Text("الدرجة الكلية") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = passingGrade,
                        onValueChange = { passingGrade = it },
                        label = { Text("درجة النجاح") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = timeLimit,
                    onValueChange = { timeLimit = it },
                    label = { Text("مدة الامتحان بالدقائق") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "الأسئلة ونموذج الإجابة السري (Admin Only):",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "سؤال 1 (اختيار من متعدد - 50 درجة):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        OutlinedTextField(
                            value = q1Text,
                            onValueChange = { q1Text = it },
                            label = { Text("نص السؤال") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = q1Correct,
                            onValueChange = { q1Correct = it },
                            label = { Text("الإجابة الصحيحة النموذجية") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "سؤال 2 (صح أو خطأ - 50 درجة):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        OutlinedTextField(
                            value = q2Text,
                            onValueChange = { q2Text = it },
                            label = { Text("نص السؤال") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = q2Correct,
                            onValueChange = { q2Correct = it },
                            label = { Text("الإجابة الصحيحة (صح / خطأ)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPublished, onCheckedChange = { isPublished = it })
                    Text(text = "نشر الامتحان للطلاب فوراً", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val examId = UUID.randomUUID().toString()
                        val exam = Exam(
                            id = examId,
                            title = title.trim(),
                            subjectName = subjectName.trim(),
                            className = className.trim(),
                            totalGrade = totalGrade.toDoubleOrNull() ?: 100.0,
                            passingGrade = passingGrade.toDoubleOrNull() ?: 50.0,
                            timeLimitMinutes = timeLimit.toIntOrNull() ?: 45,
                            isPublished = isPublished
                        )

                        val q1Id = UUID.randomUUID().toString()
                        val q2Id = UUID.randomUUID().toString()

                        val questions = listOf(
                            ExamQuestion(
                                id = q1Id,
                                examId = examId,
                                questionText = q1Text.trim(),
                                questionType = ExamQuestion.TYPE_MULTIPLE_CHOICE,
                                options = listOf("مرفوع دائماً", "منصوب دائماً", "مجرور دائماً", "مجزوم دائماً"),
                                points = 50.0
                            ),
                            ExamQuestion(
                                id = q2Id,
                                examId = examId,
                                questionText = q2Text.trim(),
                                questionType = ExamQuestion.TYPE_TRUE_FALSE,
                                options = listOf("صح", "خطأ"),
                                points = 50.0
                            )
                        )

                        val keys = listOf(
                            ExamAnswerKey(questionId = q1Id, examId = examId, correctAnswer = q1Correct.trim()),
                            ExamAnswerKey(questionId = q2Id, examId = examId, correctAnswer = q2Correct.trim())
                        )

                        onCreate(exam, questions, keys)
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("حفظ الامتحان")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdminSubmissionsScreen(viewModel: AdminViewModel) {
    val submissions by viewModel.submissions.collectAsState()
    val examinations by viewModel.examinations.collectAsState()
    var selectedSubmission by remember { mutableStateOf<ExamSubmission?>(null) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "إجابات وتسليمات الطلاب (${submissions.size})",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "مراجعة إجابات الطلاب وتصحيحها واعتماد الدرجات",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (submissions.isEmpty()) {
            EmptyState(
                icon = Icons.Default.AssignmentTurnedIn,
                title = "لا توجد تسليمات بعد",
                message = "عندما يقوم الطلاب بحل وتسليم الامتحانات ستظهر إجاباتهم هنا للمراجعة والتصحيح"
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(submissions, key = { it.id }) { sub ->
                    val exam = examinations.find { it.id == sub.examId }
                    SubmissionCard(
                        submission = sub,
                        exam = exam,
                        onReviewAndGrade = { selectedSubmission = sub }
                    )
                }
            }
        }
    }

    if (selectedSubmission != null) {
        val exam = examinations.find { it.id == selectedSubmission!!.examId } ?: Exam(
            id = selectedSubmission!!.examId,
            title = selectedSubmission!!.examTitle,
            totalGrade = 100.0,
            passingGrade = 50.0
        )
        GradeSubmissionDialog(
            submission = selectedSubmission!!,
            exam = exam,
            onDismiss = { selectedSubmission = null },
            onGrade = { manualScores, feedback ->
                viewModel.gradeSubmission(selectedSubmission!!, exam, manualScores, feedback) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    if (success) selectedSubmission = null
                }
            }
        )
    }
}

@Composable
fun SubmissionCard(
    submission: ExamSubmission,
    exam: Exam?,
    onReviewAndGrade: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(submission.submittedAt))

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = submission.studentName.ifBlank { "طالب" },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "كود الطالب: ${submission.studentCode} • امتحان: ${submission.examTitle}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                StatusBadge(status = submission.status)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "وقت التسليم: $dateStr",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onReviewAndGrade,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Grading, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("مراجعة الإجابات وتصحيح الامتحان")
            }
        }
    }
}

@Composable
fun GradeSubmissionDialog(
    submission: ExamSubmission,
    exam: Exam,
    onDismiss: () -> Unit,
    onGrade: (Map<String, Double>, String) -> Unit
) {
    var feedback by remember { mutableStateOf("عمل ممتاز") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تصحيح إجابات: ${submission.studentName}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "امتحان: ${exam.title} (الدرجة الكلية: ${exam.totalGrade.toInt()})",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(12.dp))

                submission.answers.forEach { (qId, ans) ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "إجابة الطالب:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = ans, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = feedback,
                    onValueChange = { feedback = it },
                    label = { Text("ملاحظات وتقييم الإدارة (سري)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onGrade(emptyMap(), feedback) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("اعتماد الدرجة وحفظها سرياً")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdminGradesScreen(viewModel: AdminViewModel) {
    val grades by viewModel.grades.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "سجل درجات الطلاب (سري ومحمي)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "هذا السجل متاح فقط للمسؤولين ولا يمكن للطلاب الوصول إليه إطلاقاً",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (grades.isEmpty()) {
            EmptyState(
                icon = Icons.Default.Grade,
                title = "لا توجد درجات مسجلة",
                message = "عندما تقوم بتصحيح إجابات الطلاب ستظهر الدرجات الرسمية هنا"
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(grades, key = { it.id }) { grade ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = grade.studentName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "كود: ${grade.studentCode}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                StatusBadge(status = if (grade.isPassed) "ناجح" else "راسب")
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "الدرجة المستحقة: ${grade.score.toInt()} من ${grade.totalScore.toInt()}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (grade.isPassed) Color(0xFF16A34A) else Color(0xFFDC2626)
                                )
                            )

                            if (grade.feedback.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "ملاحظات: ${grade.feedback}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
