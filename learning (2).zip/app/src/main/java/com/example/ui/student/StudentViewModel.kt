package com.example.ui.student

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.StudentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class StudentTab(val title: String) {
    HOME("الرئيسية"),
    LESSONS("الحصص الأونلاين"),
    EXAMS("الامتحانات"),
    CURRICULUM("المناهج"),
    ATTENDANCE("سجل الحضور"),
    FINANCIAL("المصاريف"),
    NOTIFICATIONS("الإشعارات"),
    PROFILE("حسابي")
}

class StudentViewModel(application: Application) : AndroidViewModel(application) {

    private val studentRepository = StudentRepository(application)

    private val _selectedTab = MutableStateFlow(StudentTab.HOME)
    val selectedTab: StateFlow<StudentTab> = _selectedTab.asStateFlow()

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _examinations = MutableStateFlow<List<Exam>>(emptyList())
    val examinations: StateFlow<List<Exam>> = _examinations.asStateFlow()

    private val _mySubmissions = MutableStateFlow<List<ExamSubmission>>(emptyList())
    val mySubmissions: StateFlow<List<ExamSubmission>> = _mySubmissions.asStateFlow()

    private val _curricula = MutableStateFlow<List<CurriculumItem>>(emptyList())
    val curricula: StateFlow<List<CurriculumItem>> = _curricula.asStateFlow()

    private val _attendance = MutableStateFlow<List<AttendanceRecord>>(emptyList())
    val attendance: StateFlow<List<AttendanceRecord>> = _attendance.asStateFlow()

    private val _financialSummary = MutableStateFlow(StudentFinancialSummary())
    val financialSummary: StateFlow<StudentFinancialSummary> = _financialSummary.asStateFlow()

    private val _fees = MutableStateFlow<List<StudentFee>>(emptyList())
    val fees: StateFlow<List<StudentFee>> = _fees.asStateFlow()

    private val _payments = MutableStateFlow<List<PaymentRecord>>(emptyList())
    val payments: StateFlow<List<PaymentRecord>> = _payments.asStateFlow()

    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Active exam state
    private val _activeExam = MutableStateFlow<Exam?>(null)
    val activeExam: StateFlow<Exam?> = _activeExam.asStateFlow()

    private val _activeQuestions = MutableStateFlow<List<ExamQuestion>>(emptyList())
    val activeQuestions: StateFlow<List<ExamQuestion>> = _activeQuestions.asStateFlow()

    private val _userAnswers = MutableStateFlow<Map<String, String>>(emptyMap())
    val userAnswers: StateFlow<Map<String, String>> = _userAnswers.asStateFlow()

    private val _submissionMessage = MutableStateFlow<String?>(null)
    val submissionMessage: StateFlow<String?> = _submissionMessage.asStateFlow()

    init {
        loadData()
    }

    fun selectTab(tab: StudentTab) {
        _selectedTab.value = tab
    }

    fun loadData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _lessons.value = studentRepository.getScheduledLessons()
                _examinations.value = studentRepository.getPublishedExaminations()
                _mySubmissions.value = studentRepository.getMySubmissions()
                _curricula.value = studentRepository.getCurriculumMaterials()
                _attendance.value = studentRepository.getMyAttendance()
                _financialSummary.value = studentRepository.getMyFinancialSummary()
                _fees.value = studentRepository.getMyFees()
                _payments.value = studentRepository.getMyPayments()
                _notifications.value = studentRepository.getMyNotifications()
            } catch (e: Exception) {
                // Handled gracefully
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun startExam(exam: Exam) {
        viewModelScope.launch {
            _isLoading.value = true
            _activeExam.value = exam
            _userAnswers.value = emptyMap()
            _activeQuestions.value = studentRepository.getExamQuestions(exam.id)
            _isLoading.value = false
        }
    }

    fun selectAnswer(questionId: String, answer: String) {
        _userAnswers.value = _userAnswers.value + (questionId to answer)
    }

    fun submitExam(onComplete: (Boolean, String) -> Unit) {
        val exam = _activeExam.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val result = studentRepository.submitExam(exam.id, exam.title, _userAnswers.value)
            _isLoading.value = false
            result.onSuccess { msg ->
                _activeExam.value = null
                _userAnswers.value = emptyMap()
                _submissionMessage.value = msg
                loadData()
                onComplete(true, msg)
            }.onFailure { err ->
                onComplete(false, err.message ?: "فشل تسليم الامتحان")
            }
        }
    }

    fun exitExam() {
        _activeExam.value = null
        _userAnswers.value = emptyMap()
    }

    fun clearSubmissionMessage() {
        _submissionMessage.value = null
    }
}
