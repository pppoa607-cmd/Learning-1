package com.example.ui.admin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudentCode
import com.example.data.model.User
import com.example.ui.components.EmptyState
import com.example.ui.components.StatusBadge
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminStudentsScreen(viewModel: AdminViewModel) {
    val students by viewModel.students.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("الكل") }

    val filtered = students.filter { student ->
        val matchesQuery = student.fullName.contains(searchQuery, ignoreCase = true) ||
                student.email.contains(searchQuery, ignoreCase = true) ||
                student.studentCode.contains(searchQuery, ignoreCase = true)

        val matchesStatus = when (statusFilter) {
            "نشط" -> student.accountStatus == User.STATUS_ACTIVE
            "معلق" -> student.accountStatus == User.STATUS_SUSPENDED
            "قيد التفعيل" -> student.accountStatus == User.STATUS_PENDING
            else -> true
        }

        matchesQuery && matchesStatus
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("بحث بالاسم، الإيميل، أو الكود...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("students_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("الكل", "نشط", "قيد التفعيل", "معلق").forEach { filter ->
                FilterChip(
                    selected = statusFilter == filter,
                    onClick = { statusFilter = filter },
                    label = { Text(filter) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            EmptyState(
                icon = Icons.Default.PeopleOutline,
                title = "لا يوجد طلاب مطابقين",
                message = "لم يتم العثور على أي طلاب في هذه الفئة"
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.uid }) { student ->
                    StudentCard(
                        student = student,
                        onToggleStatus = { newStatus ->
                            viewModel.updateStudentStatus(student.uid, newStatus)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StudentCard(
    student: User,
    onToggleStatus: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.fullName.ifBlank { "طالب بدون اسم" },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = student.email,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusBadge(status = student.accountStatus)
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "كود الطالب: ${student.studentCode.ifBlank { "غير مربوط" }}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "الصف: ${student.className}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (student.accountStatus == User.STATUS_ACTIVE) {
                        OutlinedButton(
                            onClick = { onToggleStatus(User.STATUS_SUSPENDED) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تعليق", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = { onToggleStatus(User.STATUS_ACTIVE) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تفعيل", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCodesScreen(viewModel: AdminViewModel) {
    val codes by viewModel.studentCodes.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var filterStatus by remember { mutableStateOf("الكل") }
    val context = LocalContext.current

    val filteredCodes = codes.filter { code ->
        when (filterStatus) {
            "متاح" -> code.status == StudentCode.STATUS_AVAILABLE
            "نشط" -> code.status == StudentCode.STATUS_ACTIVE
            "ملغى" -> code.status == StudentCode.STATUS_REVOKED
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "إدارة أكواد الطلاب (${codes.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Button(
                onClick = { showCreateDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("generate_new_code_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("توليد كود جديد")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("الكل", "متاح", "نشط", "ملغى").forEach { st ->
                FilterChip(
                    selected = filterStatus == st,
                    onClick = { filterStatus = st },
                    label = { Text(st) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredCodes.isEmpty()) {
            EmptyState(
                icon = Icons.Default.VpnKey,
                title = "لا توجد أكواد",
                message = "اضغط على 'توليد كود جديد' لإنشاء كود وصول للطالب",
                actionButton = {
                    Button(onClick = { showCreateDialog = true }) {
                        Text("توليد كود")
                    }
                }
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredCodes, key = { it.code }) { codeItem ->
                    StudentCodeCard(
                        item = codeItem,
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Student Code", codeItem.code))
                            Toast.makeText(context, "تم نسخ الكود: ${codeItem.code}", Toast.LENGTH_SHORT).show()
                        },
                        onRevoke = { viewModel.revokeStudentCode(codeItem.code) }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateCodeDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, assignedClass ->
                viewModel.createStudentCode(name, assignedClass) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    if (success) showCreateDialog = false
                }
            }
        )
    }
}

@Composable
fun StudentCodeCard(
    item: StudentCode,
    onCopy: () -> Unit,
    onRevoke: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(item.createdAt))

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.code,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                StatusBadge(status = item.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (item.studentName.isNotBlank() || item.studentEmail.isNotBlank()) {
                Text(
                    text = "الطالب: ${item.studentName.ifBlank { item.studentEmail }}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = "الصف: ${item.assignedClass} | تاريخ الإنشاء: $dateStr",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onCopy,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ الكود", fontSize = 12.sp)
                }

                if (item.status != StudentCode.STATUS_REVOKED) {
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = onRevoke,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إلغاء الصلاحية", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CreateCodeDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String) -> Unit
) {
    var studentName by remember { mutableStateOf("") }
    var assignedClass by remember { mutableStateOf("الصف الأول الثانوي") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("توليد كود وصول جديد") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "سيتم إنشاء كود فريد بصيغة LRN-2026-XXXXX وربطه بهذا الطالب.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = studentName,
                    onValueChange = { studentName = it },
                    label = { Text("اسم الطالب (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = assignedClass,
                    onValueChange = { assignedClass = it },
                    label = { Text("المرحلة / الصف الدراسي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(studentName, assignedClass) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("توليد الكود")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
