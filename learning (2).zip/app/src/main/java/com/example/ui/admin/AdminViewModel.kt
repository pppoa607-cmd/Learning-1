package com.example.ui.admin

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AdminRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AdminTab(val title: String) {
    DASHBOARD("لوحة التحكم"),
    STUDENTS("إدارة الطلاب"),
    CODES("أكواد الطلاب"),
    LESSONS("الحصص الأونلاين"),
    ATTENDANCE("الحضور والغياب"),
    EXAMS("الامتحانات"),
    SUBMISSIONS("إجابات الطلاب"),
    GRADES("درجات الطلاب"),
    CURRICULUM("المناهج الدراسية"),
    FINANCIAL("المصاريف والمدفوعات"),
    REPORTS("التقارير"),
    LOGS("سجل النشاطات"),
    SETTINGS("إعدادات الإدارة")
}

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    private val adminRepository = AdminRepository(application)

    private val _selectedTab = MutableStateFlow(AdminTab.DASHBOARD)
    val selectedTab: StateFlow<AdminTab> = _selectedTab.asStateFlow()

    private val _stats = MutableStateFlow(AdminRepository.AdminStats())
    val stats: StateFlow<AdminRepository.AdminStats> = _stats.asStateFlow()

    private val _students = MutableStateFlow<List<User>>(emptyList())
    val students: StateFlow<List<User>> = _students.asStateFlow()

    private val _studentCodes = MutableStateFlow<List<StudentCode>>(emptyList())
    val studentCodes: StateFlow<List<StudentCode>> = _studentCodes.asStateFlow()

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _examinations = MutableStateFlow<List<Exam>>(emptyList())
    val examinations: StateFlow<List<Exam>> = _examinations.asStateFlow()

    private val _submissions = MutableStateFlow<List<ExamSubmission>>(emptyList())
    val submissions: StateFlow<List<ExamSubmission>> = _submissions.asStateFlow()

    private val _grades = MutableStateFlow<List<ExamGrade>>(emptyList())
    val grades: StateFlow<List<ExamGrade>> = _grades.asStateFlow()

    private val _curricula = MutableStateFlow<List<CurriculumItem>>(emptyList())
    val curricula: StateFlow<List<CurriculumItem>> = _curricula.asStateFlow()

    private val _financialSummaries = MutableStateFlow<List<StudentFinancialSummary>>(emptyList())
    val financialSummaries: StateFlow<List<StudentFinancialSummary>> = _financialSummaries.asStateFlow()

    private val _activityLogs = MutableStateFlow<List<ActivityLogItem>>(emptyList())
    val activityLogs: StateFlow<List<ActivityLogItem>> = _activityLogs.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadAllData()
    }

    fun selectTab(tab: AdminTab) {
        _selectedTab.value = tab
    }

    fun loadAllData() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _stats.value = adminRepository.getDashboardStats()
                _students.value = adminRepository.getAllStudents()
                _studentCodes.value = adminRepository.getAllStudentCodes()
                _lessons.value = adminRepository.getAllLessons()
                _examinations.value = adminRepository.getAllExaminations()
                _submissions.value = adminRepository.getAllSubmissions()
                _grades.value = adminRepository.getExamGrades()
                _curricula.value = adminRepository.getAllCurricula()
                _financialSummaries.value = adminRepository.getStudentFinancialSummaries()
                _activityLogs.value = adminRepository.getActivityLogs()
            } catch (e: Exception) {
                _message.value = "خطأ في تحميل البيانات: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Students
    fun updateStudentStatus(uid: String, newStatus: String) {
        viewModelScope.launch {
            adminRepository.updateStudentStatus(uid, newStatus)
            loadAllData()
        }
    }

    // Student Codes
    fun createStudentCode(name: String, assignedClass: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.createStudentCode(name, assignedClass)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تم إنشاء الكود: ${it.code}")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إنشاء الكود")
            }
        }
    }

    fun revokeStudentCode(code: String) {
        viewModelScope.launch {
            adminRepository.revokeStudentCode(code)
            loadAllData()
        }
    }

    // Lessons
    fun createLesson(lesson: Lesson, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.createLesson(lesson)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تمت إضافة الحصة بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إضافة الحصة")
            }
        }
    }

    fun deleteLesson(lessonId: String) {
        viewModelScope.launch {
            adminRepository.deleteLesson(lessonId)
            loadAllData()
        }
    }

    fun recordAttendance(
        lessonId: String,
        lessonTitle: String,
        studentUid: String,
        studentCode: String,
        studentName: String,
        status: String
    ) {
        viewModelScope.launch {
            adminRepository.recordAttendance(lessonId, lessonTitle, studentUid, studentCode, studentName, status)
            loadAllData()
        }
    }

    // Exams
    fun createExam(
        exam: Exam,
        questions: List<ExamQuestion>,
        answerKeys: List<ExamAnswerKey>,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = adminRepository.createExamination(exam, questions, answerKeys)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تم إنشاء وتأمين الامتحان بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إنشاء الامتحان")
            }
        }
    }

    fun togglePublishExam(examId: String, isPublished: Boolean) {
        viewModelScope.launch {
            adminRepository.togglePublishExam(examId, isPublished)
            loadAllData()
        }
    }

    fun deleteExam(examId: String) {
        viewModelScope.launch {
            adminRepository.deleteExam(examId)
            loadAllData()
        }
    }

    fun gradeSubmission(
        submission: ExamSubmission,
        exam: Exam,
        manualScores: Map<String, Double>,
        feedback: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = adminRepository.gradeSubmission(submission, exam, manualScores, feedback)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تم حفظ الدرجة في سجل درجات الطلاب السري بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل تصحيح الامتحان")
            }
        }
    }

    // Curriculum
    fun createCurriculum(item: CurriculumItem, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.createCurriculum(item)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تمت إضافة المحتوى التعليمي بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إضافة المحتوى")
            }
        }
    }

    fun deleteCurriculum(itemId: String) {
        viewModelScope.launch {
            adminRepository.deleteCurriculum(itemId)
            loadAllData()
        }
    }

    // Financial
    fun addFee(fee: StudentFee, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.addStudentFee(fee)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تمت إضافة الرسوم بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إضافة الرسوم")
            }
        }
    }

    fun recordPayment(payment: PaymentRecord, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.recordPayment(payment)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تم تسجيل الدفعة واحتساب الرصيد المتبقي بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل تسجيل الدفعة")
            }
        }
    }

    fun sendAnnouncement(title: String, body: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = adminRepository.sendAnnouncement(title, body)
            result.onSuccess {
                loadAllData()
                onComplete(true, "تم إرسال الإشعار لجميع الطلاب بنجاح")
            }.onFailure {
                onComplete(false, it.message ?: "فشل إرسال الإشعار")
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
