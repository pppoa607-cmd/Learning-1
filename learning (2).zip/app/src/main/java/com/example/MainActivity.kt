package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.admin.AdminMainScreen
import com.example.ui.admin.AdminViewModel
import com.example.ui.auth.*
import com.example.ui.components.RtlProvider
import com.example.ui.student.StudentMainScreen
import com.example.ui.student.StudentViewModel
import com.example.ui.theme.LearningAppTheme

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LearningAppTheme {
                RtlProvider {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        MainAppContent(authViewModel = authViewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun MainAppContent(authViewModel: AuthViewModel) {
    val uiState by authViewModel.uiState.collectAsState()

    when (val state = uiState) {
        is AuthUiState.Idle -> {
            SignInScreen(
                isLoading = false,
                errorMessage = null,
                onSignInClick = { authViewModel.signInWithGoogle() },
                onDismissError = { authViewModel.clearError() }
            )
        }
        is AuthUiState.Loading -> {
            SignInScreen(
                isLoading = true,
                errorMessage = null,
                onSignInClick = {},
                onDismissError = { authViewModel.clearError() }
            )
        }
        is AuthUiState.Error -> {
            SignInScreen(
                isLoading = false,
                errorMessage = state.message,
                onSignInClick = { authViewModel.signInWithGoogle() },
                onDismissError = { authViewModel.clearError() }
            )
        }
        is AuthUiState.NeedsName -> {
            NameOnboardingScreen(
                user = state.user,
                isLoading = false,
                errorMessage = null,
                onSubmit = { authViewModel.submitFullName(it) }
            )
        }
        is AuthUiState.PendingActivation -> {
            CodeActivationScreen(
                user = state.user,
                onActivate = { code, callback ->
                    authViewModel.activateCode(code, callback)
                },
                onSignOut = { authViewModel.signOut() }
            )
        }
        is AuthUiState.Authenticated -> {
            if (state.user.isAdmin) {
                val adminViewModel: AdminViewModel = viewModel()
                AdminMainScreen(
                    adminUser = state.user,
                    viewModel = adminViewModel,
                    onSignOut = { authViewModel.signOut() }
                )
            } else {
                val studentViewModel: StudentViewModel = viewModel()
                StudentMainScreen(
                    studentUser = state.user,
                    viewModel = studentViewModel,
                    onSignOut = { authViewModel.signOut() }
                )
            }
        }
    }
}
