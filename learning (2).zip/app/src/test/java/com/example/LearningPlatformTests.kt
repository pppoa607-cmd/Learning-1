package com.example

import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class LearningPlatformTests {

    // TEST 1: A new student signs in with Google and is asked to enter their name if blank.
    @Test
    fun test1_newStudentNeedsNameWhenBlank() {
        val newStudent = User(
            uid = "student_123",
            email = "student@example.com",
            fullName = "", // blank name
            role = User.ROLE_STUDENT,
            accountStatus = User.STATUS_PENDING
        )

        assertTrue("New user with blank name must require name onboarding", newStudent.fullName.isBlank())
        assertTrue("Role must be student", newStudent.isStudent)
        assertFalse("Account must be pending activation", newStudent.isActive)
    }

    // TEST 2: A student enters a valid unused code and successfully activates their account.
    @Test
    fun test2_studentEntersValidUnusedCode_activatesSuccessfully() {
        val studentCode = StudentCode(
            code = "LRN-2026-A7K92",
            status = StudentCode.STATUS_AVAILABLE
        )
        val student = User(
            uid = "student_123",
            fullName = "أحمد محمد",
            role = User.ROLE_STUDENT,
            accountStatus = User.STATUS_PENDING
        )

        assertTrue("Code is available", studentCode.isAvailable)

        // Activation simulation
        val activatedCode = studentCode.copy(
            status = StudentCode.STATUS_ACTIVE,
            studentUid = student.uid,
            studentName = student.fullName,
            activatedAt = System.currentTimeMillis()
        )
        val activatedStudent = student.copy(
            studentCode = activatedCode.code,
            accountStatus = User.STATUS_ACTIVE
        )

        assertEquals(StudentCode.STATUS_ACTIVE, activatedCode.status)
        assertEquals(student.uid, activatedCode.studentUid)
        assertTrue(activatedStudent.isActive)
        assertEquals("LRN-2026-A7K92", activatedStudent.studentCode)
    }

    // TEST 3: A student tries to use another student's already activated code. The operation must fail.
    @Test
    fun test3_studentCannotUseAlreadyActivatedCode() {
        val alreadyActiveCode = StudentCode(
            code = "LRN-2026-A7K92",
            studentUid = "first_student_uid",
            status = StudentCode.STATUS_ACTIVE
        )
        val secondStudentUid = "second_student_uid"

        val canClaim = alreadyActiveCode.status == StudentCode.STATUS_AVAILABLE
        assertFalse("Cannot claim an already active code", canClaim)
        assertNotEquals(secondStudentUid, alreadyActiveCode.studentUid)
    }

    // TEST 4: A student attempts to access the administrator dashboard. Access must be denied.
    @Test
    fun test4_studentCannotAccessAdminFeatures() {
        val student = User(
            uid = "student_123",
            role = User.ROLE_STUDENT
        )
        val adminZiad = User(
            uid = "admin_ziad",
            email = "ozilziad24@gmail.com",
            fullName = "زياد الطنساوي",
            role = User.ROLE_ADMIN
        )
        val adminNada = User(
            uid = "admin_nada",
            email = "zt067313@gmail.com",
            fullName = "ندي الطنساوي",
            role = User.ROLE_ADMIN
        )

        assertFalse("Student cannot have admin permissions", student.isAdmin)
        assertTrue("Ziad must have admin permissions", adminZiad.isAdmin)
        assertEquals("زياد الطنساوي", adminZiad.fullName)
        assertTrue("Nada must have admin permissions", adminNada.isAdmin)
        assertEquals("ندي الطنساوي", adminNada.fullName)
    }

    // TEST 5: A student submits an examination. The submission is saved successfully.
    @Test
    fun test5_studentSubmitsExamination() {
        val exam = Exam(
            id = "exam_1",
            title = "امتحان اللغة العربية",
            totalGrade = 100.0,
            passingGrade = 50.0
        )
        val studentAnswers = mapOf(
            "q1" to "مرفوع دائماً",
            "q2" to "صح"
        )
        val submission = ExamSubmission(
            id = "sub_1",
            examId = exam.id,
            examTitle = exam.title,
            studentUid = "student_123",
            studentCode = "LRN-2026-A7K92",
            answers = studentAnswers,
            status = ExamSubmission.STATUS_SUBMITTED
        )

        assertEquals("sub_1", submission.id)
        assertEquals(ExamSubmission.STATUS_SUBMITTED, submission.status)
        assertEquals(2, submission.answers.size)
    }

    // TEST 6: The student tries to read their grade directly from database. Access denied / privacy preserved.
    @Test
    fun test6_gradePrivacyPreservedFromStudentSubmission() {
        val submission = ExamSubmission(
            id = "sub_1",
            examId = "exam_1",
            studentUid = "student_123",
            answers = mapOf("q1" to "مرفوع دائماً")
        )

        // The student submission object NEVER contains grades or correct answers
        val gradeObject = ExamGrade(
            id = "grade_1",
            submissionId = submission.id,
            examId = submission.examId,
            studentUid = submission.studentUid,
            score = 100.0,
            totalScore = 100.0,
            isPassed = true,
            feedback = "تقييم سري"
        )

        // Verification: Submission has no score or correct answer fields
        assertNotEquals(submission::class.java, gradeObject::class.java)
        assertEquals(100.0, gradeObject.score, 0.01)
    }

    // TEST 7: The administrator can view the student's submitted answers and grade.
    @Test
    fun test7_adminCanViewSubmissionAndCalculateGrade() {
        val questions = listOf(
            ExamQuestion(id = "q1", points = 50.0),
            ExamQuestion(id = "q2", points = 50.0)
        )
        val answerKeys = mapOf(
            "q1" to "مرفوع دائماً",
            "q2" to "صح"
        )
        val studentAnswers = mapOf(
            "q1" to "مرفوع دائماً",
            "q2" to "صح"
        )

        var score = 0.0
        for (q in questions) {
            val correct = answerKeys[q.id]
            val studentAns = studentAnswers[q.id]
            if (correct != null && correct == studentAns) {
                score += q.points
            }
        }

        assertEquals(100.0, score, 0.01)
    }

    // TEST 8: The administrator creates a lesson and records attendance.
    @Test
    fun test8_adminCreatesLessonAndRecordsAttendance() {
        val lesson = Lesson(
            id = "lesson_101",
            title = "مراجعة الجبر والهندسة",
            subjectName = "الرياضيات",
            meetingLink = "https://meet.google.com/abc-defg-hij"
        )
        val attendance = AttendanceRecord(
            id = "${lesson.id}_student_123",
            lessonId = lesson.id,
            lessonTitle = lesson.title,
            studentUid = "student_123",
            studentCode = "LRN-2026-A7K92",
            studentName = "أحمد محمد",
            status = AttendanceRecord.STATUS_PRESENT,
            recordedBy = "admin@example.com"
        )

        assertEquals("lesson_101", lesson.id)
        assertEquals(AttendanceRecord.STATUS_PRESENT, attendance.status)
        assertEquals("admin@example.com", attendance.recordedBy)
    }

    // TEST 9: A student cannot modify their official attendance record.
    @Test
    fun test9_studentCannotModifyAttendanceRecord() {
        val userRole = User.ROLE_STUDENT
        val canModifyAttendance = userRole == User.ROLE_ADMIN
        assertFalse("Students must not be able to modify official attendance", canModifyAttendance)
    }

    // TEST 10: The administrator records a partial payment and the remaining balance is calculated correctly.
    @Test
    fun test10_partialPaymentRemainingBalanceCalculation() {
        val fees = listOf(
            StudentFee(id = "fee_1", studentUid = "st_1", amount = 600.0),
            StudentFee(id = "fee_2", studentUid = "st_1", amount = 400.0)
        )
        val payments = listOf(
            PaymentRecord(id = "pay_1", studentUid = "st_1", amount = 350.0, paymentMethod = PaymentRecord.METHOD_VODAFONE_CASH)
        )

        val totalFees = fees.sumOf { it.amount }
        val totalPaid = payments.sumOf { it.amount }
        val remainingBalance = (totalFees - totalPaid).coerceAtLeast(0.0)

        assertEquals(1000.0, totalFees, 0.01)
        assertEquals(350.0, totalPaid, 0.01)
        assertEquals(650.0, remainingBalance, 0.01)
    }

    // TEST 11: A student attempts to read another student's financial information. Access must be denied.
    @Test
    fun test11_crossStudentFinancialPrivacy() {
        val requestingStudentUid = "student_A"
        val targetFee = StudentFee(id = "fee_1", studentUid = "student_B", amount = 500.0)

        val isAuthorized = requestingStudentUid == targetFee.studentUid
        assertFalse("Student A cannot access Student B's financial records", isAuthorized)
    }

    // TEST 12: An unauthorized user attempts to edit the curriculum. Access must be denied.
    @Test
    fun test12_unauthorizedUserCannotEditCurriculum() {
        val studentUser = User(uid = "st_1", role = User.ROLE_STUDENT)
        val adminUser = User(uid = "adm_1", role = User.ROLE_ADMIN)

        val studentCanEdit = studentUser.role == User.ROLE_ADMIN
        val adminCanEdit = adminUser.role == User.ROLE_ADMIN

        assertFalse("Student cannot edit curriculum", studentCanEdit)
        assertTrue("Admin can edit curriculum", adminCanEdit)
    }
}
